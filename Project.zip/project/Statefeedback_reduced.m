clc; clear;

% 系统参数
m = 0.1;
M = 1.0;
b = 0.5;
b_g = 0.3;
k1 = 0;
k = 0;
eta = 0.8;
r = 1;

% 状态空间建模（含双弹簧 + 阻尼）
A = [  0     1        0              0;
     -k1/m  ((M/m)-1)*b/(M-m)     0           0;
      0      0        0              1;
      0     -b*(M+m)/(m*(M-m))  0  0];

B = [0; 1/(m-M); 0; -1/(m-M)];

C = eye(4);
D = zeros(4,1);

% 可控性检查
rank_ctrb = rank(ctrb(A, B));
disp(['系统可控性秩为：', num2str(rank_ctrb)]);  % 应为 4

if rank_ctrb < 4
    error('系统不是完全可控，无法使用 place() 配置全部极点');
end

% 极点配置
P = [-2; -3; -4; -5];
K = place(A, B, P);

% 闭环系统
A_cl = A - B * K;
disp('闭环系统特征值:');
disp(eig(A_cl));

sys_cl = ss(A_cl, [], eye(4), 0);

% 初始状态
z0 = [0.05; 0.01; 0; 0];
t = 0:0.01:5;

[y, ~, x] = initial(sys_cl, z0, t);
tau = - (K * x')';

%% 开环系统响应（无控制输入 u = 0）
sys_open = ss(A, B, C, D);

% 同样初始状态
[y_open, ~, x_open] = initial(sys_open, z0, t);

% 画图
figure;

subplot(4,1,1);
plot(t, x_open(:,1)*100, 'k--', 'LineWidth', 1.5); hold on;
plot(t, x(:,1)*100, 'b', 'LineWidth', 2);
title('小球位置 x_b (cm)'); legend('开环','闭环'); grid on;

subplot(4,1,2);
plot(t, x_open(:,2)*100, 'k--', 'LineWidth', 1.5); hold on;
plot(t, x(:,2)*100, 'r', 'LineWidth', 2);
title('小球速度 \dot{x}_b (cm/s)'); legend('开环','闭环'); grid on;

subplot(4,1,3);
plot(t, x_open(:,3)*100, 'k--', 'LineWidth', 1.5); hold on;
plot(t, x(:,3)*100, 'm', 'LineWidth', 2);
title('滑块位置 x_c (cm)'); legend('开环','闭环'); grid on;

subplot(4,1,4);
plot(t, x_open(:,4)*100, 'k--', 'LineWidth', 1.5); hold on;
plot(t, x(:,4)*100, 'c', 'LineWidth', 2);
title('滑块速度 \dot{x}_c (cm/s)'); legend('开环','闭环'); grid on;
xlabel('时间 (s)');

figure;

subplot(5,1,1);
plot(t, x(:,1)*100, 'b');
title('小球位置 x_b (cm)'); grid on;

subplot(5,1,2);
plot(t, x(:,2)*100, 'r');
title('小球速度 \dot{x}_b (cm/s)'); grid on;

subplot(5,1,3);
plot(t, x(:,3)*100, 'm');
title('滑块位置 x_c (cm)'); grid on;

subplot(5,1,4);
plot(t, x(:,4)*100, 'c');
title('滑块速度 \dot{x}_c (cm/s)'); grid on;

subplot(5,1,5);
plot(t, tau, 'g');
title('控制力 u (N)');
xlabel('时间 (s)');
grid on;
%% 跟踪reference state
clc;
clear;

% 系统参数
m = 0.1;  % 小球质量 (kg)
M = 1.0;  % 滑块质量 (kg)
b = 0.5;  % 摩擦系数 (kg/s)

% 状态空间矩阵
A = [0 1;
     0 b*((M/m) - 1)/(M - m)];
B = [0; 1/(m - M)];
C = [1 0];
D = 0;

% 极点配置
P = [-2; -3];
K = acker(A, B, P);

% 闭环矩阵与输入增益
A_cl = A - B * K;
B_ref = B * K;  % 相当于参考状态的输入

% 参考状态 [位置(m); 速度(m/s)]
x_ref = [0.05; 0];  % 期望位移为5cm，速度为0

% 构建带参考输入的状态空间系统
sys_cl = ss(A_cl, B_ref, C, D);

% 初始状态：位置为0，速度为0.01 m/s
z0 = [0; 0.01];
A0 = [0 0.01 ; 0 0];
% 模拟时间
t = 0:0.01:5;

% 输入为恒定参考状态
u_ref = repmat(x_ref', length(t), 1);  % 每一行都是参考状态

% 仿真系统响应（使用 lsim）
[y, t, z] = lsim(sys_cl, u_ref, t, z0);

% 计算控制输入
tau = - (K * (z' - x_ref));  % u = -K(x - x_ref)
tau = tau';
KT = K';
% 绘图
figure;
subplot(3,1,1);
plot(t, z(:,1)*100, 'b', 'LineWidth', 2); hold on;
yline(x_ref(1)*100, 'k--', 'LineWidth', 1.5);
grid on;
title('小球位移 x_1 (cm)');
xlabel('时间 (s)');
ylabel('x_1 (cm)');
legend('实际位移', '参考位移');

subplot(3,1,2);
plot(t, z(:,2)*100, 'r', 'LineWidth', 2); hold on;
yline(x_ref(2)*100, 'k--', 'LineWidth', 1.5);
grid on;
title('小球速度 \dot{x}_1 (cm/s)');
xlabel('时间 (s)');
ylabel('\dot{x}_1 (cm/s)');
legend('实际速度', '参考速度');

subplot(3,1,3);
plot(t, tau, 'g', 'LineWidth', 2);
grid on;
title('控制力 \tau (N)');
xlabel('时间 (s)');
ylabel('\tau (N)');

%% 
% Zero reference state input
clc;
clear;

% 系统参数
m = 0.1;  % 小球质量 (kg)
M = 1.0;  % 滑块质量 (kg)
b = 0.5;  % 摩擦系数 (kg/s)
eta = 0.8;
r = 1;

% 状态空间矩阵
A = [ 0       1         0       0;
      0   -b/m        0     b/m;
      0       0         0       1;
      0    b/M        0    -b/M ];

B = [ 0;
      0;
      0;
     eta/r*M ];
C = [1 0 0 0;
     0 1 0 0;
     0 0 1 0;
     0 0 0 1];
D = [0;0;0;0];

n = size(A,1);  % 系统阶数
m_input = size(B,2);  % 输入维数

cvx_begin sdp
    variable P(n,n) symmetric
    variable Y(m_input,n)

    % LMI constraint
    Acl = A * P - B * Y;
    Acl_symmetric = Acl' + Acl;

    minimize(0)
    subject to
        P >= 1e-6 * eye(n);       % P ≻ 0
        Acl_symmetric <= -1e-6 * eye(n);  % Acl' + Acl ≺ 0
cvx_end
%% clc;
clc;
clear;

% 系统参数
m = 0.1;
M = 1.0;
b = 0.5;
eta = 0.8;
r = 1;

% 原始系统
A = [ 0       1         0       0;
      0   -b/m        0     b/m;
      0       0         0       1;
      0    b/M        0    -b/M ];

B = [ 0;
      0;
      0;
     eta/(r*M) ];

C = eye(4);
D = zeros(4,1);

% 可控性分析
rank_ctrb = rank(ctrb(A, B));
disp(['系统可控性秩为：', num2str(rank_ctrb)]);  % 应为 3

% 可控性分解
[T, A_bar, B_bar, ~] = ctrbf(A, B, C);
n = size(A,1);
r = rank_ctrb;     % 可控维度
nc = r;
nuc = n - r;

% 提取可控子系统
A_c = A_bar(1:nc, 1:nc);
B_c = B_bar(1:nc, :);

% 极点设计（稳定负实数）
P_c = linspace(-2, -4, nc)';  % e.g., [-2; -3; -4]
K_c = place(A_c, B_c, P_c);

% 还原到原系统空间
K_full = [K_c, zeros(1, nuc)] * T';

% 构建闭环系统
A_cl = A - B*K_full;
disp('闭环系统矩阵 A_cl:');
disp(A_cl);
disp('闭环特征值:');
disp(eig(A_cl));

sys_cl = ss(A_cl, [], eye(4), 0);

% 初始状态（必须长度=4）
z0 = [0.05; 0.01; 0; 0];
t = 0:0.01:5;
[y, ~, x] = initial(sys_cl, z0, t);

% 控制输入
tau = - (K_full * x')';

% 绘图
figure;
subplot(4,1,1);
plot(t, x(:,1)*100, 'b'); title('小球位置 x_b (cm)'); grid on;

subplot(4,1,2);
plot(t, x(:,2)*100, 'r'); title('小球速度 \dot{x}_b (cm/s)'); grid on;

subplot(4,1,3);
plot(t, x(:,3)*100, 'm'); title('小车位置 x_c (cm)'); grid on;

subplot(4,1,4);
plot(t, tau, 'g'); title('控制力 u (N)'); xlabel('时间 (s)'); grid on;
%% 可控性验证
A = [  0     1        0              0;
        0  -b/m       0           b/m;
        0     0        0              1;
        0   b/M    -k/M       -(b + b_g)/M ];

B = [0; 0; 0; eta / (r*M)];

Co = ctrb(A, B);
rank_Co = rank(Co);

% 获取系统特征值
eigs_A = eig(A);

% 可控模态
[~, d] = eig(A);
[v, ~] = eig(A);

% 遍历每个模态，判断是否在可控子空间
fprintf('\n系统特征值和可控性：\n');
for i = 1:length(eigs_A)
    lambda = eigs_A(i);
    test_mat = [lambda*eye(size(A)) - A, B];
    rk = rank(test_mat);

    if real(lambda) >= 0
        if rk < size(A,1)
            fprintf('❌ 模态 %.2f 不稳定且不可控 ➝ 系统不可稳定化\n', lambda);
        else
            fprintf('✅ 模态 %.2f 不稳定但可控\n', lambda);
        end
    else
        fprintf('✔ 模态 %.2f 是稳定的\n', lambda);
    end
end

%% 新设计
% --- 系统参数定义 ---
m = 0.5;  % 小球质量 (kg)
M = 5.0;  % 桌子质量 (kg)
k = 10;   % 绳索弹性系数 (N/m)
c = 1;    % 绳索阻尼系数 (Ns/m)
b = 0.5;  % 桌面摩擦系数 (Ns/m)

% --- 状态空间矩阵 ---
A = [ 0,        1,          0,         0;
     -k/m,  -(c+b)/m,      k/m,     (c+b)/m;
      0,        0,          0,         1;
      k/M,   (c+b)/M,     -k/M,    -(c+b)/M ];

B = [0; 0; 0; 1/M];

% 选择输出: y = [x_b - x_t; x_t]
C = [ 1, 0, -1, 0;
      0, 0,  1, 0 ];
% 如果只测量相对位置 (不可观测)
% H_rel = [1, 0, -1, 0];

D = [0; 0]; % 直接馈通矩阵

% 创建状态空间系统对象
sys = ss(A, B, C, D);
fprintf('系统阶数 n = %d\n', order(sys));

% --- 分析 ---
fprintf('\n--- 系统分析 ---\n');
% 稳定性
fprintf('开环系统特征值 (稳定性):\n');
disp(eig(A));
if any(real(eig(A)) >= -0.1)
    fprintf('开环系统不稳定或临界稳定。\n');
else
    fprintf('开环系统稳定。\n');
end

% 可控性
fprintf('\n可控性分析:\n');
Co = ctrb(A, B); % 或者 ctrb(sys)
rank_Co = rank(Co);
fprintf('可控性矩阵秩: %d\n', rank_Co);
if rank_Co == order(sys)
    fprintf('系统完全可控。\n');
    fprintf('系统能稳。\n');
else
    fprintf('系统不可控。\n');
    % 检查能稳性需要进一步分析不可控模态
    fprintf('由于不可控，需要进一步分析能稳性。\n');
end

% 可观测性
fprintf('\n可观测性分析 (输出 y = [x_b-x_t; x_t]):\n');
Ob = obsv(A, C); % 或者 obsv(sys)
rank_Ob = rank(Ob);
fprintf('可观测性矩阵秩: %d\n', rank_Ob);
if rank_Ob == order(sys)
    fprintf('系统可观测。\n');
else
    fprintf('系统不可观测。\n');
end

% % 检查只测量相对位置的可观测性 (可选)
% Ob_rel = obsv(A, H_rel);
% rank_Ob_rel = rank(Ob_rel);
% fprintf('\n可观测性分析 (输出 y = x_b-x_t):\n');
% fprintf('可观测性矩阵秩: %d\n', rank_Ob_rel);
% if rank_Ob_rel == order(sys)
%     fprintf('系统可观测。\n');
% else
%     fprintf('系统不可观测。\n');
% end

% --- 控制器与观测器设计 ---
fprintf('\n--- 控制器与观测器设计 ---\n');

% 1. 状态反馈控制器设计 (极点配置)
fprintf('设计状态反馈控制器 K...\n');
% 期望的闭环极点 (选择稳定且具有合适的响应速度和阻尼)
% 例如: p1=-1, p2=-1.1, p3=-1.5, p4=-2.0
P_ctrl = [-1.0, -1.1, -1.5, -2.0];
% P_ctrl = [-1+1i, -1-1i, -2, -3]; % 包含复数极点

try
    K = place(A, B, P_ctrl); % 使用 place 函数计算反馈增益 K
    fprintf('状态反馈增益 K:\n');
    disp(K);

    % 验证闭环极点
    Acl = A - B*K;
    fprintf('闭环系统 (A-BK) 的特征值:\n');
    disp(eig(Acl));
catch ME
    fprintf('无法使用 place 计算 K (可能是系统不可控或数值问题): %s\n', ME.message);
    K = []; % K 未能计算
end

% 2. 状态观测器设计 (Luenberger Observer)
fprintf('\n设计状态观测器 L...\n');
% 期望的观测器极点 (比控制器极点快 5-10 倍)
P_obs = 5 * P_ctrl; % 简单示例，可以更细致地选择
% P_obs = [-8, -9, -10, -11];

try
    % 使用 place 设计观测器增益 L (注意 A' 和 H')
    L_transpose = place(A', C', P_obs);
    L = L_transpose'; % 转置得到 L
    fprintf('观测器增益 L:\n');
    disp(L);

    % 验证观测器误差动态特性 (A-LH) 的特征值
    Aobs = A - L*C;
    fprintf('观测器误差动态 (A-LH) 的特征值:\n');
    disp(eig(Aobs));
catch ME
    fprintf('无法使用 place 计算 L (可能是系统不可观测或数值问题): %s\n', ME.message);
    L = []; % L 未能计算
end

% --- 仿真 (需要 L 和 K 都已成功计算) ---
if ~isempty(K) && ~isempty(L)
    fprintf('\n--- 仿真 ---\n');
    t = 0:0.01:15; % 仿真时间

    % 构建包含控制器和观测器的闭环系统 (较复杂)
    % 或者分别仿真系统和观测器
    % 这里演示分别仿真

    % 定义系统和观测器的初始状态
    X0 = [0.5; 0; 0; 0]; % 小球偏离中心 0.5m，初始速度为 0
    X0_hat = [0; 0; 0; 0]; % 观测器初始估计为 0

    % 定义仿真函数
    % Plant: dX/dt = A*X + B*u
    % Observer: dX_hat/dt = A*X_hat + B*u + L*(y - H*X_hat)
    % Control: u = -K*X_hat
    % Output: y = H*X
    ode_func = @(t, states) [
        % states = [X; X_hat] (8x1 vector)
        % Plant dynamics (first 4 states)
        A * states(1:4) + B * (-K * states(5:8));
        % Observer dynamics (last 4 states)
        A * states(5:8) + B * (-K * states(5:8)) + L * (C * states(1:4) - C * states(5:8));
    ];

    % 运行仿真
    [T, STATES] = ode45(ode_func, t, [X0; X0_hat]);

    % 提取结果
    X_sim = STATES(:, 1:4);
    X_hat_sim = STATES(:, 5:8);
    U_sim = -K * X_hat_sim'; % 计算控制输入 u(t)

    % 计算相对位置和速度
    x_rel_sim = X_sim(:,1) - X_sim(:,3);
    v_rel_sim = X_sim(:,2) - X_sim(:,4);

    % 绘图
    figure;

    subplot(3, 2, 1);
    plot(T, X_sim(:,1), 'b-', T, X_hat_sim(:,1), 'r--');
    title('小球位置 x_b'); xlabel('时间 (s)'); ylabel('位置 (m)'); legend('实际', '估计'); grid on;

    subplot(3, 2, 2);
    plot(T, X_sim(:,2), 'b-', T, X_hat_sim(:,2), 'r--');
    title('小球速度 v_b'); xlabel('时间 (s)'); ylabel('速度 (m/s)'); legend('实际', '估计'); grid on;

    subplot(3, 2, 3);
    plot(T, X_sim(:,3), 'b-', T, X_hat_sim(:,3), 'r--');
    title('桌子位置 x_t'); xlabel('时间 (s)'); ylabel('位置 (m)'); legend('实际', '估计'); grid on;

    subplot(3, 2, 4);
    plot(T, X_sim(:,4), 'b-', T, X_hat_sim(:,4), 'r--');
    title('桌子速度 v_t'); xlabel('时间 (s)'); ylabel('速度 (m/s)'); legend('实际', '估计'); grid on;

    subplot(3, 2, 5);
    plot(T, x_rel_sim, 'k-');
    title('相对位置 x_{rel} = x_b - x_t'); xlabel('时间 (s)'); ylabel('位置 (m)'); grid on;
    hold on; plot(T, zeros(size(T)), 'g:'); hold off; % Target line

    subplot(3, 2, 6);
    plot(T, U_sim, 'm-');
    title('控制输入 F'); xlabel('时间 (s)'); ylabel('力 (N)'); grid on;

    figure;
    plot(T, X_sim(:,1)-X_hat_sim(:,1), T, X_sim(:,2)-X_hat_sim(:,2), ...
         T, X_sim(:,3)-X_hat_sim(:,3), T, X_sim(:,4)-X_hat_sim(:,4));
    title('状态估计误差 (X - X_{hat})'); xlabel('时间 (s)'); ylabel('误差');
    legend('e_{xb}', 'e_{vb}', 'e_{xt}', 'e_{vt}'); grid on;

else
    fprintf('\n控制器或观测器未能成功设计，无法进行仿真。\n');
end


A_obs = A - L*C;
B_obs = [B, L]; % B_obs will be 4x3 if y has 2 elements
C_obs = eye(size(A)); % Output is the estimated state X_hat (Identity matrix)
D_obs = zeros(size(A,1), size(B_obs,2)); % No direct feedthrough

%% CVX
% --- 系统参数定义 ---
clc;
clear all;
close all;
m = 0.5;  % 小球质量 (kg)
M = 5.0;  % 桌子质量 (kg)
k = 10;   % 绳索弹性系数 (N/m)
c = 1;    % 绳索阻尼系数 (Ns/m)
b = 0.5;  % 桌面摩擦系数 (Ns/m)
eta = 0.7;
r = 1;

% --- 状态空间矩阵 ---
A = [ 0,        1,          0,         0;
     -k/m,  -(c+b)/m,      k/m,     (c+b)/m;
      0,        0,          0,         1;
      k/M,   (c+b)/M,     -k/M,    -(c+b)/M ];

B = [0; 0; 0; eta/(r*M)];

% 选择输出: y = [x_b - x_t; x_t]
C = [ 1, 0, -1, 0;
      0, 0,  1, 0 ];

D = [0; 0]; % 直接馈通矩阵

n = size(A, 1); % 系统阶数 (状态维度)
m_in = size(B, 2); % 输入维度
p = size(C, 1); % 输出维度

% 创建状态空间系统对象
sys = ss(A, B, C, D);
fprintf('系统阶数 n = %d\n', n);

% --- 分析 ---
fprintf('\n--- 系统分析 ---\n');
% 稳定性
fprintf('开环系统特征值 (稳定性):\n');
eig_A = eig(A);
disp(eig_A);
if any(real(eig_A) >= -1e-9)
    fprintf('开环系统不稳定或临界稳定。\n');
else
    fprintf('开环系统稳定。\n');
end

% 可控性
fprintf('\n可控性分析:\n');
Co = ctrb(A, B);
rank_Co = rank(Co);
fprintf('可控性矩阵秩: %d\n', rank_Co);
if rank_Co == n
    fprintf('系统完全可控。\n');
    fprintf('系统能稳。\n');
else
    fprintf('系统不可控。\n');
    fprintf('由于不可控，需要进一步分析能稳性。\n');
end

% 可观测性
fprintf('\n可观测性分析 (输出 y = [x_b-x_t; x_t]):\n');
Ob = obsv(A, C);
rank_Ob = rank(Ob);
fprintf('可观测性矩阵秩: %d\n', rank_Ob);
if rank_Ob == n
    fprintf('系统可观测。\n');
else
    fprintf('系统不可观测。\n');
end

% --- 控制器设计 (使用 CVX LMI) ---
fprintf('\n--- 使用 CVX LMI 设计状态反馈控制器 K ---\n');

if rank_Co == n % 仅在系统可控时尝试设计
    epsilon = 1e-6;

    % ****** 修改点：去掉了 quiet ******
    cvx_begin sdp % 使用 SDP 模式，显示求解过程
        % 定义 LMI 变量
        variable Q(n,n) symmetric % Q = P^-1 > 0
        variable Y(m_in, n)       % Y = K*Q

        % LMI 约束
        % 1. Q > 0
        Q >= epsilon * eye(n);

        % 2. A*Q + Q*A' - B*Y - Y'*B' < 0
        A*Q + Q*A' - B*Y - Y'*B' <= -epsilon * eye(n);

    cvx_end
    % ************************************

    % 检查 CVX 求解状态
    if strfind(cvx_status, 'Solved')
        fprintf('CVX LMI 求解成功。\n');
        K_lmi = Y / Q;
        fprintf('状态反馈增益 K (LMI):\n');
        disp(K_lmi);
        Acl_lmi = A - B*K_lmi;
        fprintf('闭环系统 (A-BK_lmi) 的特征值:\n');
        eig_Acl_lmi = eig(Acl_lmi);
        disp(eig_Acl_lmi);
        if all(real(eig_Acl_lmi) < 0)
             fprintf('LMI 控制器使闭环系统稳定。\n');
             K = K_lmi;
        else
             fprintf('警告: LMI 控制器未能使闭环系统稳定 (数值问题?)。\n');
             K = [];
        end
    else
        fprintf('CVX LMI 求解失败。状态: %s\n', cvx_status);
        fprintf('无法使用 LMI 计算 K。\n');
        K = [];
    end
else
    fprintf('系统不可控，无法保证使用 LMI 找到稳定化 K。\n');
    K = [];
end

% --- 如果 LMI 失败或不可控，可以尝试使用 place (作为备选) ---
if isempty(K) && rank_Co == n
    fprintf('\n--- LMI 失败，尝试使用 Place 设计控制器 K ---\n');
    P_ctrl = [-1.0, -1.1, -1.5, -2.0];
    try
        K_place = place(A, B, P_ctrl);
        fprintf('状态反馈增益 K (Place):\n');
        disp(K_place);
        Acl_place = A - B*K_place;
        fprintf('闭环系统 (A-BK_place) 的特征值:\n');
        disp(eig(Acl_place));
        K = K_place;
    catch ME
        fprintf('无法使用 place 计算 K: %s\n', ME.message);
        K = [];
    end
end

% --- 观测器设计 (使用 CVX LMI) ---
fprintf('\n--- 使用 CVX LMI 设计状态观测器 L ---\n');
L = [];
% 观测器设计仅依赖于可观测性
if rank_Ob == n
    epsilon = 1e-6; % Can reuse epsilon from controller design

    % ****** 修改点：使用 CVX LMI 设计观测器 ******
    cvx_begin sdp % Use quiet mode unless debugging needed
        % 定义 LMI 变量 (针对对偶问题)
        variable Qo(n,n) symmetric % Qo = P_observer^-1 > 0
        variable Yo(p, n)       % Yo = L' * Qo (p is output dim, n is state dim)

        % LMI 约束 (基于 A'Q + QA - C'Y - Y'C < 0)
        % 1. Qo > 0
        Qo >= epsilon * eye(n);

        % 2. A'*Qo + Qo*A - C'*Yo - Yo'*C < 0
        A'*Qo + Qo*A - C'*Yo - Yo'*C <= -epsilon * eye(n);

    cvx_end
    % *******************************************

    % 检查 CVX 求解状态
    if strfind(cvx_status, 'Solved')
        fprintf('CVX LMI 求解成功 (观测器)。\n');
        % 从 LMI 解恢复观测器增益 L
        % Yo = L'*Qo  =>  L' = Yo * inv(Qo) => L = inv(Qo)' * Yo'
        % Since Qo is symmetric, inv(Qo)' = inv(Qo)
        % L = inv(Qo) * Yo'
        L = Qo \ Yo'; % More numerically stable than inv(Qo)*Yo'

        fprintf('观测器增益 L (LMI):\n');
        disp(L);
        Aobs = A - L*C;
        fprintf('观测器误差动态 (A-LC) 的特征值:\n');
        eig_Aobs = eig(Aobs);
        disp(eig_Aobs);
         if all(real(eig_Aobs) < 0)
             fprintf('LMI 观测器使误差动态稳定。\n');
        else
             fprintf('警告: LMI 观测器未能使误差动态稳定 (数值问题?)。\n');
             L = []; % Reset L if stability not achieved
        end
    else
        fprintf('CVX LMI 求解失败 (观测器)。状态: %s\n', cvx_status);
        fprintf('无法使用 LMI 计算 L。\n');
        L = [];
    end
else
     fprintf('系统不可观测，无法设计观测器。\n');
     L = []; % Ensure L is empty if not observable
end


% --- 仿真 (需要 L 和 K 都已成功计算) ---
if ~isempty(K) && ~isempty(L)
    fprintf('\n--- 仿真 ---\n');
    A_obs = A - L*C;
    B_obs = [B, L];
    C_obs = eye(n);
    D_obs = zeros(n, m_in + p);

    fprintf('Simulink Observer Matrices:\n');
    fprintf('A_obs:\n'); disp(A_obs);
    fprintf('B_obs:\n'); disp(B_obs);
    fprintf('C_obs:\n'); disp(C_obs);
    fprintf('D_obs:\n'); disp(D_obs);
    fprintf('Gain K:\n'); disp(K);
    fprintf('Plant A, B, C, D are defined.\n');
    fprintf('Initial conditions X0, X0_hat need to be set.\n');

    % === MATLAB 仿真部分 (可选) ===
    t = 0:0.01:15;
    X0 = [0.5; 0; 0; 0];
    X0_hat = [0; 0; 0; 0];

    ode_func = @(t, states) [
        A * states(1:n) + B * (-K * states(n+1:2*n));
        A * states(n+1:2*n) + B * (-K * states(n+1:2*n)) + L * (C * states(1:n) - C * states(n+1:2*n));
    ];
    [T, STATES] = ode45(ode_func, t, [X0; X0_hat]);
    X_sim = STATES(:, 1:n);
    X_hat_sim = STATES(:, n+1:2*n);
    U_sim = -K * X_hat_sim';
    x_rel_sim = X_sim(:,1) - X_sim(:,3);

    % ... (之前的绘图代码) ...
     figure;
     subplot(3, 2, 1); plot(T, X_sim(:,1), 'b-', T, X_hat_sim(:,1), 'r--'); title('Ball Position x_b'); legend('actual', 'Est'); grid on;
     subplot(3, 2, 2); plot(T, X_sim(:,2), 'b-', T, X_hat_sim(:,2), 'r--'); title('Ball Velocity v_b'); legend('actual', 'Est'); grid on;
     subplot(3, 2, 3); plot(T, X_sim(:,3), 'b-', T, X_hat_sim(:,3), 'r--'); title('Table Position x_t'); legend('actual', 'Est'); grid on;
     subplot(3, 2, 4); plot(T, X_sim(:,4), 'b-', T, X_hat_sim(:,4), 'r--'); title('Table Velocity v_t'); legend('actual', 'Est'); grid on;
     subplot(3, 2, 5); plot(T, x_rel_sim, 'k-'); title('Relative Position x_{rel}'); hold on; plot(T, zeros(size(T)), 'g:'); hold off; grid on;
     subplot(3, 2, 6); plot(T, U_sim', 'm-'); title('Control Input F'); grid on; % 注意 U_sim 需要转置回来
     figure; plot(T, X_sim - X_hat_sim); title('State Estimation Error (X - X_{hat})'); legend('e_{xb}', 'e_{vb}', 'e_{xt}', 'e_{vt}'); grid on;

else
    fprintf('\n控制器或观测器未能成功设计，无法进行仿真。\n');
    K = nan(m_in, n);
    L = nan(n, p);
    A_obs = nan(n, n);
    B_obs = nan(n, m_in+p);
    C_obs = nan(n, n);
    D_obs = nan(n, m_in+p);
end

% 确保 X0 和 X0_hat 总是存在
if ~exist('X0','var'); X0 = zeros(n,1); end
if ~exist('X0_hat','var'); X0_hat = zeros(n,1); end

%% step autonomous
% --- (Previous code: System parameters, A, B, C, D, n, m_in, p) ---
% --- (Previous code: Analysis - Stability, Controllability, Observability) ---
% --- (Previous code: Controller Design - K calculation using LMI or Place) ---
% --- (Previous code: Observer Design - L calculation using Place) ---

% Ensure K and L have been successfully calculated before proceeding
if isempty(K) || isempty(L)
    error('Controller K or Observer L not available. Cannot proceed with simulation.');
end

fprintf('\n--- Closed-Loop System Simulation ---\n');

% === Construct Augmented System Matrix for Autonomous Response ===
A_aug = [ A,       -B*K;
          L*C,   A - L*C - B*K ];
% Define B_aug as zeros for the autonomous system (no external input)
B_aug_aut = zeros(2*n, 1);
% Define C_aug to select outputs of interest: X, X_hat, x_rel, u
C_aug = [ eye(n),    zeros(n);      % Output: X (Actual States 1-4)
          zeros(n),  eye(n);        % Output: X_hat (Estimated States 5-8)
          [1 0 -1 0], zeros(1,n);   % Output: x_rel = x_b - x_t (Output 9)
          zeros(1,n), -K          ]; % Output: u = -K*X_hat (Output 10)
D_aug_aut = zeros(size(C_aug, 1), size(B_aug_aut, 2));

sys_aug_aut = ss(A_aug, B_aug_aut, C_aug, D_aug_aut);
fprintf('Autonomous closed-loop system (sys_aug_aut) created.\n');

% === 1. Simulate Autonomous Response using initial ===
fprintf('\nSimulating Autonomous Response (using initial)...\n');
t_sim = 0:0.01:15; % Simulation time vector
X0 = [0.5; 0; 0; 0];      % Initial condition for Plant
X0_hat = [0; 0; 0; 0];      % Initial condition for Observer
X_aug_0 = [X0; X0_hat];     % Combined initial condition

% Simulate using 'initial'
[Y_aut, T_aut, X_aug_sim_aut] = initial(sys_aug_aut, X_aug_0, t_sim);

% Extract results from Y_aut
X_sim_aut = Y_aut(:, 1:n);      % Actual states X
X_hat_sim_aut = Y_aut(:, n+1:2*n); % Estimated states X_hat
x_rel_sim_aut = Y_aut(:, 2*n + 1); % Relative position x_rel
U_sim_aut = Y_aut(:, 2*n + 2);   % Control input u

% Plot Autonomous Response
figure('Name', 'Autonomous Response (using initial)');
subplot(3, 2, 1); plot(T_aut, X_sim_aut(:,1), 'b-', T_aut, X_hat_sim_aut(:,1), 'r--'); title('x_b'); legend('Actual', 'Est.'); grid on;
subplot(3, 2, 2); plot(T_aut, X_sim_aut(:,2), 'b-', T_aut, X_hat_sim_aut(:,2), 'r--'); title('v_b'); legend('Actual', 'Est.'); grid on;
subplot(3, 2, 3); plot(T_aut, X_sim_aut(:,3), 'b-', T_aut, X_hat_sim_aut(:,3), 'r--'); title('x_t'); legend('Actual', 'Est.'); grid on;
subplot(3, 2, 4); plot(T_aut, X_sim_aut(:,4), 'b-', T_aut, X_hat_sim_aut(:,4), 'r--'); title('v_t'); legend('Actual', 'Est.'); grid on;
subplot(3, 2, 5); plot(T_aut, x_rel_sim_aut, 'k-'); title('x_{rel}'); grid on; hold on; plot(T_aut, zeros(size(T_aut)), 'g:'); hold off;
subplot(3, 2, 6); plot(T_aut, U_sim_aut, 'm-'); title('Control Input u=F'); grid on;
sgtitle('Autonomous System Response from Initial Condition');

%%
% === 2. Simulate Step Response using step ===
fprintf('\nSimulating Step Response (using step)...\n');

% --- Define Closed-Loop System with Reference Input ---
% We need the system from reference 'r' to outputs 'x_t' and 'x_rel'
% Control law: u = -KX_hat + N_r*r
% Dynamics: dX_aug/dt = A_aug*X_aug + B_aug_ref*r
% Calculate N_r first (same as before)
Acl = A - B*K;
N_r = NaN; % Initialize
if abs(det(Acl)) > 1e-9
    H_dc = C * (-inv(Acl)) * B;
    if abs(H_dc(2)) > 1e-9
        N_r = 1 / H_dc(2);
        fprintf('Feedforward Gain N_r = %f\n', N_r);
    else
        fprintf('Warning: DC gain to x_t near zero for N_r calc.\n');
    end
else
    fprintf('Warning: Closed-loop matrix A-BK singular for N_r calc.\n');
end

if isnan(N_r)
    fprintf('Cannot perform step response simulation because N_r is invalid.\n');
else
    % Define the input matrix for the reference input r
    B_aug_ref = [B * N_r; B * N_r]; % r affects both Plant and Observer via u

    % Define the output matrix for step response: x_t and x_rel
    C_step = [ 0 0 1 0   zeros(1, n);  % Output: x_t (Actual Table Position)
               1 0 -1 0  zeros(1, n) ]; % Output: x_rel (Actual Relative Position)
    D_step = zeros(size(C_step, 1), 1); % No direct feedthrough from r

    % sys_step = ss(A_aug, B_aug_ref, C_step, D_step);
    sys_step = ss(A_aug, B_aug_ref , C_step , D_step);
    fprintf('Closed-loop system for step response (sys_step) created.\n');

    % Define step amplitude
    step_amplitude = 1; % Desired step in table position x_t

    % Simulate using 'step'
    t_step = 0:0.01:25; % Longer time for settling
    [Y_step, T_step] = step(sys_step * step_amplitude, t_step);

    % Y_step has two columns: scaled x_t response, scaled x_rel response

    % Plot Step Response
    figure('Name', 'Step Response (using step)');
    subplot(2, 1, 1);
    plot(T_step, Y_step(:,1), 'b-'); % Plot x_t response
    hold on;
    plot(T_step, ones(size(T_step)) * step_amplitude, 'r:'); % Plot reference line
    title('Step Response: Table Position x_t');
    xlabel('Time (s)'); ylabel('Position (m)');
    legend('Actual x_t', 'Reference'); grid on;

    subplot(2, 1, 2);
    plot(T_step, Y_step(:,2), 'k-'); % Plot x_rel response
    title('Step Response: Relative Position x_{rel}');
    xlabel('Time (s)'); ylabel('Position (m)');
    grid on; ylim([-0.1 0.1]); % Zoom y-axis

    sgtitle('Step Response of Table Position (using step)');

end
%%
% === 3. Simulate Step Response using lsim (Alternative) ===
fprintf('\nSimulating Step Response (using lsim as alternative)...\n');
if isnan(N_r)
     fprintf('Cannot perform lsim step response simulation because N_r is invalid.\n');
else
    % Use the same system as for step, but define output differently if needed
    % Let's output X, X_hat, x_rel, u using lsim
    C_lsim = C_aug; % Use the same C_aug as in autonomous simulation
    D_lsim = [zeros(size(C_lsim,1)-1, 1); N_r]; % Direct feedthrough for u = -KX_hat + Nr*r ? No, D relates r to y. u is internal. D is zero.
    D_lsim = zeros(size(C_lsim,1), 1);

    sys_lsim = ss(A_aug, B_aug_ref, C_lsim, D_lsim);
    fprintf('Closed-loop system for lsim (sys_lsim) created.\n');

    % Define step input signal for lsim
    t_lsim = t_step; % Use the same time vector
    step_time = 1.0;
    R_lsim = (t_lsim >= step_time) * step_amplitude; % Step input vector

    % Simulate using lsim (zero initial condition for pure step response)
    X0_aug_lsim = zeros(2*n, 1);
    [Y_lsim, T_lsim, X_aug_sim_lsim] = lsim(sys_lsim, R_lsim, t_lsim, X0_aug_lsim);

    % Extract results from Y_lsim (same structure as Y_aut)
    X_sim_lsim = Y_lsim(:, 1:n);
    X_hat_sim_lsim = Y_lsim(:, n+1:2*n);
    x_rel_sim_lsim = Y_lsim(:, 2*n + 1);
    U_sim_lsim = Y_lsim(:, 2*n + 2);

    % Plot Step Response from lsim
    figure('Name', 'Step Response (using lsim)');
    subplot(3, 2, 1); plot(T_lsim, X_sim_lsim(:,1), 'b-', T_lsim, X_hat_sim_lsim(:,1), 'r--'); title('x_b'); legend('Actual', 'Est.'); grid on;
    subplot(3, 2, 2); plot(T_lsim, X_sim_lsim(:,2), 'b-', T_lsim, X_hat_sim_lsim(:,2), 'r--'); title('v_b'); legend('Actual', 'Est.'); grid on;
    subplot(3, 2, 3); plot(T_lsim, X_sim_lsim(:,3), 'b-', T_lsim, X_hat_sim_lsim(:,3), 'r--'); hold on; plot(T_lsim, R_lsim, 'k:'); title('x_t'); legend('Actual', 'Est.', 'Ref.'); grid on;
    subplot(3, 2, 4); plot(T_lsim, X_sim_lsim(:,4), 'b-', T_lsim, X_hat_sim_lsim(:,4), 'r--'); title('v_t'); legend('Actual', 'Est.'); grid on;
    subplot(3, 2, 5); plot(T_lsim, x_rel_sim_lsim, 'k-'); title('x_{rel}'); grid on; hold on; plot(T_lsim, zeros(size(T_lsim)), 'g:'); hold off; ylim([-0.1 0.1]);
    subplot(3, 2, 6); plot(T_lsim, U_sim_lsim, 'm-'); title('Control Input u=F'); grid on;
    sgtitle('Step Response of Table Position (using lsim)');
end


% --- Ensure previous required variables exist ---
% (Same as before, ensure A, B, C, K, L, n, etc. are defined)
if ~exist('K','var'); error('K not defined'); end
if ~exist('L','var'); error('L not defined'); end
% ... add checks or ensure the full script runs sequentially
%% Controllability Gramian
% Assuming A and B are defined as before
Wc = gram(ss(Acl_lmi,B,eye(4),0), 'c'); % Calculate controllability Gramian
disp('Controllability Gramian Wc:');
disp(Wc);

% Analyze diagonal elements (rough indicator in this coordinate system)
disp('Diagonal elements of Wc:');
disp(diag(Wc));

% Analyze eigenvalues and eigenvectors
[V_c, D_c] = eig(Wc);
disp('Eigenvalues of Wc (indicating ease of control in eigendirections):');
disp(diag(D_c)); % Larger eigenvalues = easier control
disp('Eigenvectors of Wc (columns define controllable directions):');
disp(V_c);

%% SVD
[U, S, V] = svd(Co);

% 状态变量标签（按顺序）
state_labels = {'x_b', 'v_b', 'x_t', 'v_t'};

% 遍历每个可控主方向
for i = 1:size(V,2)
    fprintf('\n Main direction %d (sigualr value %.4f):\n', i, S(i,i));
    for j = 1:length(state_labels)
        fprintf('  %-3s: %+0.4f\n', state_labels{j}, V(j,i));
    end
end

%% Observability
% Assuming A and C are defined
Ob = obsv(A, C);
[Uo, So, Vo] = svd(Ob);

singular_values_o = diag(So);
min_singular_value_o = singular_values_o(end); % Smallest singular value
max_singular_value_o = singular_values_o(1);   % Largest singular value

fprintf('Singular values of Observability Matrix:\n');
disp(singular_values_o);

% Check observability based on smallest singular value
observable_svd = (min_singular_value_o > 1e-9); % Using a tolerance
fprintf('System observable based on SVD? %d\n', observable_svd);

if observable_svd
    condition_number_o = max_singular_value_o / min_singular_value_o;
    fprintf('Condition number (s_max / s_min): %e\n', condition_number_o);

    fprintf('State direction MOST affecting output (corresponds to s_max, represented by Vo(:,1)):\n');
    disp(Vo(:,1)); % Vo(:,1) shows the state combination most easily observed
    fprintf('State direction LEAST affecting output (corresponds to s_min, represented by Vo(:,4)):\n');
    disp(Vo(:,4)); % Vo(:,4) shows the state combination hardest to observe
else
    fprintf('System is not fully observable with these outputs.\n');
end
[U, S, V] = svd(Ob);

% 状态变量标签（按顺序）
state_labels = {'x_b', 'v_b', 'x_t', 'v_t'};

% 遍历每个可控主方向
for i = 1:size(V,2)
    fprintf('\n Main direction %d (sigualr value %.4f):\n', i, S(i,i));
    for j = 1:length(state_labels)
        fprintf('  %-3s: %+0.4f\n', state_labels{j}, V(j,i));
    end
end