%% ---------------- 1. 物理与模型参数 ----------------
m   = 0.5;   % Ball mass  (kg)
M   = 5.0;   % Table mass (kg)
k   = 10;    % Spring stiffness (N/m)
c   = 1;     % Damping coefficient (Ns/m)
b   = 0.5;   % Friction coefficient (Ns/m)
eta = 0.7;   % Efficiency factor
r   = 1;     % Lever arm (m)

A = [  0,        1,          0,        0;
     -k/m, -(c+b)/m,      k/m,  (c+b)/m;
       0,        0,          0,        1;
      k/M,  (c+b)/M,    -k/M, -(c+b)/M];

B  = [0; 0; 0; eta/(r*M)];    % 控制输入
B1 = B;                       % 过程扰动（与输入同通道，可按需修改）

%% ---------------- 2. H2 设计权函数 ----------------
rho = 0.1;     % 控制加权因子
C1  = [ 1, 0,-1, 0;           % z = [位移误差; 桌面位移; 虚拟 0]
        0, 0, 1, 0;
        0, 0, 0, 0];
D12 = [0; 0; rho];            % z 对 u 的馈通

%% ---------------- 3. LMI 维度 ----------------
n  = size(A,1);   % 状态维度   (4)
m  = size(B,2);   % 输入维度   (1)
p1 = size(B1,2);  % 扰动维度   (1)
q  = size(C1,1);  % 受控输出  (3)

%% ---------------- 4. 使用 CVX 求解 ----------------
tol = 1e-6;       % 数值容差
cvx_solver sdpt3
fprintf('\nSolving H2 state-feedback LMI …\n');

cvx_begin sdp
    variable X(n,n)   symmetric
    variable Y(m,n)               % Y = K·X
    variable Z(q,q)   symmetric   % H2 变量 (欲最小化 trace(Z))

    minimize( trace(Z) )
    subject to
        % 正定性
        X >= tol*eye(n);

        % ① 稳定性 & ② H2 性能综合 LMI
        %
        %  ┌                        ┐
        %  │  A X + X Aᵀ − B Y − Yᵀ Bᵀ     B1              (C1 X − D12 Y)ᵀ │
        %  │       B1ᵀ               −I                     0              │ < 0
        %  │  C1 X − D12 Y           0                    −Z              │
        %  └                        ┘
        %
        big   =  [A*X + X*A' - B*Y - Y'*B',     B1,                   (C1*X - D12*Y)';
                  B1',                        -eye(p1),              zeros(p1,q);
                  C1*X - D12*Y,               zeros(q,p1),           -Z           ];
        big <= -tol*eye(n+p1+q);
cvx_end

if ~strcmp(cvx_status,'Solved')
    error('CVX did not converge: %s', cvx_status);
end

%% ---------------- 5. 得到反馈增益 & 稳定性验证 ----------------
K = Y / X;                 % 反馈增益
Acl = A - B*K;             % 闭环 A 矩阵
fprintf('Closed-loop eigenvalues:\n'); disp(eig(Acl).');

if any(real(eig(Acl)) >= 0)
    warning('闭环系统未达到渐近稳定！');
else
    disp('闭环系统渐近稳定。');
end

%% ---------------- 6. 精确计算 H2 范数 ----------------
% 通过求解可达格拉米安 P (Lyapunov) 计算: ||G||_H2^2 = trace(Ccl P Cclᵀ)
Ccl = C1 - D12*K;
P    = lyap(Acl, B1*B1');                   % Lyapunov: Acl P + P Aclᵀ + B1 B1ᵀ = 0
h2   = sqrt(trace(Ccl*P*Ccl'));
fprintf('Closed-loop H2 norm  = %.6f\n', h2);