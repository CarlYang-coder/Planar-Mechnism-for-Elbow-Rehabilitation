%% CVX

clc; clear;

% --- System parameters ---
m = 0.5;    % Ball mass (kg)
M = 5.0;    % Table mass (kg)
k = 10;     % Spring stiffness (N/m)
c = 1;      % Damping coefficient (Ns/m)
b = 0.5;    % Surface friction coefficient (Ns/m)
eta = 0.7;  % Motor efficiency
r = 1;      % Gear ratio

% --- State space matrix ---
A = [ 0,        1,          0,         0;
     -k/m,  -(c+b)/m,      k/m,     (c+b)/m;
      0,        0,          0,         1;
      k/M,   (c+b)/M,     -k/M,    -(c+b)/M ];

B = [0; 0; 0; eta/(r*M)];

% Output: y = [x_b - x_t; x_t]
C = [ 1, 0, -1, 0;
      0, 0,  1, 0 ];

D = [0; 0]; % Direct feedthrough matrix

n = size(A, 1);     % System order (state dimension)
m_in = size(B, 2);  % Input dimension
p = size(C, 1);     % Output dimension

% Create state-space system
sys = ss(A, B, C, D);
fprintf('System order n = %d\n', n);

% --- Analysis ---
fprintf('\n--- System Analysis ---\n');

% Stability check
fprintf('Open-loop eigenvalues:\n');
eig_A = eig(A);
disp(eig_A);
if any(real(eig_A) >= -1e-9)
    fprintf('Open-loop system is unstable or marginally stable.\n');
else
    fprintf('Open-loop system is stable.\n');
end

% Controllability
fprintf('\nControllability Analysis:\n');
Co = ctrb(A, B);
rank_Co = rank(Co);
fprintf('Controllability matrix rank: %d\n', rank_Co);
if rank_Co == n
    fprintf('System is fully controllable.\n');
else
    fprintf('System is not controllable.\n');
    fprintf('Stabilizability must be checked.\n');
end

% Observability
fprintf('\nObservability Analysis (output y = [x_b-x_t; x_t]):\n');
Ob = obsv(A, C);
rank_Ob = rank(Ob);
fprintf('Observability matrix rank: %d\n', rank_Ob);
if rank_Ob == n
    fprintf('System is observable.\n');
else
    fprintf('System is not observable.\n');
end

% --- Controller design (CVX LMI method) ---
fprintf('\n--- Designing State Feedback Controller K via CVX LMI ---\n');

if rank_Co == n
    epsilon = 1e-6;

    cvx_begin sdp
        variable Q(n,n) symmetric
        variable Y(m_in, n)

        Q >= epsilon * eye(n);
        A*Q + Q*A' - B*Y - Y'*B' <= -epsilon * eye(n);
    cvx_end

    if contains(cvx_status, 'Solved')
        fprintf('CVX LMI solved successfully.\n');
        K_lmi = Y / Q;
        fprintf('State feedback gain K (LMI):\n');
        disp(K_lmi);
        Acl_lmi = A - B*K_lmi;
        fprintf('Closed-loop eigenvalues (A-BK_lmi):\n');
        disp(eig(Acl_lmi));
        if all(real(eig(Acl_lmi)) < 0)
            fprintf('LMI-based controller stabilizes the system.\n');
            K = K_lmi;
        else
            fprintf('Warning: LMI controller does not stabilize the system.\n');
            K = [];
        end
    else
        fprintf('CVX LMI failed. Status: %s\n', cvx_status);
        K = [];
    end
else
    fprintf('System is not controllable. Cannot design LMI controller.\n');
    K = [];
end

% --- If LMI fails, try pole placement ---
if isempty(K) && rank_Co == n
    fprintf('\n--- LMI failed, trying pole placement ---\n');
    P_ctrl = [-1.0, -1.1, -1.5, -2.0];
    try
        K_place = place(A, B, P_ctrl);
        fprintf('State feedback gain K (place):\n');
        disp(K_place);
        Acl_place = A - B*K_place;
        fprintf('Closed-loop eigenvalues (A-BK_place):\n');
        disp(eig(Acl_place));
        K = K_place;
    catch ME
        fprintf('Pole placement failed: %s\n', ME.message);
        K = [];
    end
end

% --- Observer design ---
fprintf('\n--- Designing Observer Gain L (via place) ---\n');
L = [];
if rank_Ob == n && ~isempty(K)
    P_obs = [-5.0, -5.5, -7.5, -10.0];
    try
        L_transpose = place(A', C', P_obs);
        L = L_transpose';
        fprintf('Observer gain L:\n');
        disp(L);
        Aobs = A - L*C;
        fprintf('Observer error dynamics eigenvalues (A-LC):\n');
        disp(eig(Aobs));
    catch ME
        fprintf('Observer design failed: %s\n', ME.message);
        L = [];
    end
else
     if rank_Ob ~= n
         fprintf('System is not observable. Cannot design observer.\n');
     elseif isempty(K)
         fprintf('Controller not available. Skipping observer design.\n');
     end
     L = [];
end

% --- Simulation (only if K and L are available) ---
if ~isempty(K) && ~isempty(L)
    fprintf('\n--- Simulation ---\n');
    A_obs = A - L*C;
    B_obs = [B, L];
    C_obs = eye(n);
    D_obs = zeros(n, m_in + p);

    fprintf('Simulink Observer Matrices:\n');
    fprintf('A_obs:\n'); disp(A_obs);
    fprintf('B_obs:\n'); disp(B_obs);
    fprintf('C_obs:\n'); disp(C_obs);
    fprintf('D_obs:\n'); disp(D_obs);
    fprintf('Gain K:\n'); disp(K);
    fprintf('Plant A, B, C, D are defined.\n');
    fprintf('Initial conditions X0, X0_hat need to be set.\n');

    % --- MATLAB ODE Simulation ---
    t = 0:0.01:15;
    X0 = [0.5; 0; 0; 0];
    X0_hat = [0; 0; 0; 0];

    ode_func = @(t, states) [
        A * states(1:n) + B * (-K * states(n+1:2*n));
        A * states(n+1:2*n) + B * (-K * states(n+1:2*n)) + L * (C * states(1:n) - C * states(n+1:2*n));
    ];
    [T, STATES] = ode45(ode_func, t, [X0; X0_hat]);
    X_sim = STATES(:, 1:n);
    X_hat_sim = STATES(:, n+1:2*n);
    U_sim = -K * X_hat_sim';
    x_rel_sim = X_sim(:,1) - X_sim(:,3);

    % --- Plotting results ---
    figure;
    subplot(3, 2, 1); plot(T, X_sim(:,1), 'b-', T, X_hat_sim(:,1), 'r--'); title('Ball position x_b'); legend('True', 'Estimated'); grid on;
    subplot(3, 2, 2); plot(T, X_sim(:,2), 'b-', T, X_hat_sim(:,2), 'r--'); title('Ball velocity v_b'); legend('True', 'Estimated'); grid on;
    subplot(3, 2, 3); plot(T, X_sim(:,3), 'b-', T, X_hat_sim(:,3), 'r--'); title('Table position x_t'); legend('True', 'Estimated'); grid on;
    subplot(3, 2, 4); plot(T, X_sim(:,4), 'b-', T, X_hat_sim(:,4), 'r--'); title('Table velocity v_t'); legend('True', 'Estimated'); grid on;
    subplot(3, 2, 5); plot(T, x_rel_sim, 'k-'); title('Relative position x_{rel}'); hold on; plot(T, zeros(size(T)), 'g:'); hold off; grid on;
    subplot(3, 2, 6); plot(T, U_sim', 'm-'); title('Control input F'); grid on;

    figure; plot(T, X_sim - X_hat_sim); title('State Estimation Error (X - X_{hat})'); legend('e_{xb}', 'e_{vb}', 'e_{xt}', 'e_{vt}'); grid on;

else
    fprintf('\nController or observer not available. Simulation aborted.\n');
    K = nan(m_in, n);
    L = nan(n, p);
    A_obs = nan(n, n);
    B_obs = nan(n, m_in+p);
    C_obs = nan(n, n);
    D_obs = nan(n, m_in+p);
end

% Ensure X0 and X0_hat are always defined
if ~exist('X0','var'); X0 = zeros(n,1); end
if ~exist('X0_hat','var'); X0_hat = zeros(n,1); end


%% step autonomous
% --- (Previous code: System parameters, A, B, C, D, n, m_in, p) ---
% --- (Previous code: Analysis - Stability, Controllability, Observability) ---
% --- (Previous code: Controller Design - K calculation using LMI or Place) ---
% --- (Previous code: Observer Design - L calculation using Place) ---

% Ensure K and L have been successfully calculated before proceeding
if isempty(K) || isempty(L)
    error('Controller K or Observer L not available. Cannot proceed with simulation.');
end

fprintf('\n--- Closed-Loop System Simulation ---\n');

% === Construct Augmented System Matrix for Autonomous Response ===
A_aug = [ A,       -B*K;
          L*C,   A - L*C - B*K ];
% Define B_aug as zeros for the autonomous system (no external input)
B_aug_aut = zeros(2*n, 1);
% Define C_aug to select outputs of interest: X, X_hat, x_rel, u
C_aug = [ eye(n),    zeros(n);      % Output: X (Actual States 1-4)
          zeros(n),  eye(n);        % Output: X_hat (Estimated States 5-8)
          [1 0 -1 0], zeros(1,n);   % Output: x_rel = x_b - x_t (Output 9)
          zeros(1,n), -K          ]; % Output: u = -K*X_hat (Output 10)
D_aug_aut = zeros(size(C_aug, 1), size(B_aug_aut, 2));

sys_aug_aut = ss(A_aug, B_aug_aut, C_aug, D_aug_aut);
fprintf('Autonomous closed-loop system (sys_aug_aut) created.\n');

% === 1. Simulate Autonomous Response using initial ===
fprintf('\nSimulating Autonomous Response (using initial)...\n');
t_sim = 0:0.01:15; % Simulation time vector
X0 = [0.5; 0.5; 0; 0];      % Initial condition for Plant
X0_hat = [0; 0; 0; 0];      % Initial condition for Observer
X_aug_0 = [X0; X0_hat];     % Combined initial condition

% Simulate using 'initial'
[Y_aut, T_aut, X_aug_sim_aut] = initial(sys_aug_aut, X_aug_0, t_sim);

% Extract results from Y_aut
X_sim_aut = Y_aut(:, 1:n);      % Actual states X
X_hat_sim_aut = Y_aut(:, n+1:2*n); % Estimated states X_hat
x_rel_sim_aut = Y_aut(:, 2*n + 1); % Relative position x_rel
U_sim_aut = Y_aut(:, 2*n + 2);   % Control input u

% Plot Autonomous Response
figure('Name', 'Autonomous Response (using initial)');
subplot(3, 2, 1); plot(T_aut, X_sim_aut(:,1), 'b-', T_aut, X_hat_sim_aut(:,1), 'r--'); title('x_b'); legend('Actual', 'Est.'); grid on;
subplot(3, 2, 2); plot(T_aut, X_sim_aut(:,2), 'b-', T_aut, X_hat_sim_aut(:,2), 'r--'); title('v_b'); legend('Actual', 'Est.'); grid on;
subplot(3, 2, 3); plot(T_aut, X_sim_aut(:,3), 'b-', T_aut, X_hat_sim_aut(:,3), 'r--'); title('x_t'); legend('Actual', 'Est.'); grid on;
subplot(3, 2, 4); plot(T_aut, X_sim_aut(:,4), 'b-', T_aut, X_hat_sim_aut(:,4), 'r--'); title('v_t'); legend('Actual', 'Est.'); grid on;
subplot(3, 2, 5); plot(T_aut, x_rel_sim_aut, 'k-'); title('x_{rel}'); grid on; hold on; plot(T_aut, zeros(size(T_aut)), 'g:'); hold off;
subplot(3, 2, 6); plot(T_aut, U_sim_aut, 'm-'); title('Control Input u=F'); grid on;
sgtitle('Autonomous System Response from Initial Condition');

%%
% === 2. Simulate Step Response using step ===
fprintf('\nSimulating Step Response (using step)...\n');

% --- Define Closed-Loop System with Reference Input ---
% We need the system from reference 'r' to outputs 'x_t' and 'x_rel'
% Control law: u = -KX_hat + N_r*r
% Dynamics: dX_aug/dt = A_aug*X_aug + B_aug_ref*r
% Calculate N_r first (same as before)
Acl = A - B*K;
N_r = NaN; % Initialize
if abs(det(Acl)) > 1e-9
    H_dc = C * (-inv(Acl)) * B;
    if abs(H_dc(2)) > 1e-9
        N_r = 1 / H_dc(2);
        fprintf('Feedforward Gain N_r = %f\n', N_r);
    else
        fprintf('Warning: DC gain to x_t near zero for N_r calc.\n');
    end
else
    fprintf('Warning: Closed-loop matrix A-BK singular for N_r calc.\n');
end

if isnan(N_r)
    fprintf('Cannot perform step response simulation because N_r is invalid.\n');
else
    % Define the input matrix for the reference input r
    B_aug_ref = [B * N_r; B * N_r]; % r affects both Plant and Observer via u

    % Define the output matrix for step response: x_t and x_rel
    C_step = [ 0 0 1 0   zeros(1, n);  % Output: x_t (Actual Table Position)
               1 0 -1 0  zeros(1, n) ]; % Output: x_rel (Actual Relative Position)
    D_step = zeros(size(C_step, 1), 1); % No direct feedthrough from r

    % sys_step = ss(A_aug, B_aug_ref, C_step, D_step);
    sys_step = ss(A_aug, B_aug_ref , C_step , D_step);
    fprintf('Closed-loop system for step response (sys_step) created.\n');

    % Define step amplitude
    step_amplitude = 1; % Desired step in table position x_t

    % Simulate using 'step'
    t_step = 0:0.01:25; % Longer time for settling
    [Y_step, T_step] = step(sys_step * step_amplitude, t_step);

    % Y_step has two columns: scaled x_t response, scaled x_rel response

    % Plot Step Response
    figure('Name', 'Step Response (using step)');
    subplot(2, 1, 1);
    plot(T_step, Y_step(:,1), 'b-'); % Plot x_t response
    hold on;
    plot(T_step, ones(size(T_step)) * step_amplitude, 'r:'); % Plot reference line
    title('Step Response: Table Position x_t');
    xlabel('Time (s)'); ylabel('Position (m)');
    legend('Actual x_t', 'Reference'); grid on;

    subplot(2, 1, 2);
    plot(T_step, Y_step(:,2), 'k-'); % Plot x_rel response
    title('Step Response: Relative Position x_{rel}');
    xlabel('Time (s)'); ylabel('Position (m)');
    grid on; ylim([-0.1 0.1]); % Zoom y-axis

    sgtitle('Step Response of Table Position (using step)');

end
%%
% === 3. Simulate Step Response using lsim (Alternative) ===
fprintf('\nSimulating Step Response (using lsim as alternative)...\n');
if isnan(N_r)
     fprintf('Cannot perform lsim step response simulation because N_r is invalid.\n');
else
    % Use the same system as for step, but define output differently if needed
    % Let's output X, X_hat, x_rel, u using lsim
    C_lsim = C_aug; % Use the same C_aug as in autonomous simulation
    D_lsim = [zeros(size(C_lsim,1)-1, 1); N_r]; % Direct feedthrough for u = -KX_hat + Nr*r ? No, D relates r to y. u is internal. D is zero.
    D_lsim = zeros(size(C_lsim,1), 1);

    sys_lsim = ss(A_aug, B_aug_ref, C_lsim, D_lsim);
    fprintf('Closed-loop system for lsim (sys_lsim) created.\n');

    % Define step input signal for lsim
    t_lsim = t_step; % Use the same time vector
    step_time = 1.0;
    R_lsim = (t_lsim >= step_time) * step_amplitude; % Step input vector

    % Simulate using lsim (zero initial condition for pure step response)
    X0_aug_lsim = zeros(2*n, 1);
    [Y_lsim, T_lsim, X_aug_sim_lsim] = lsim(sys_lsim, R_lsim, t_lsim, X0_aug_lsim);

    % Extract results from Y_lsim (same structure as Y_aut)
    X_sim_lsim = Y_lsim(:, 1:n);
    X_hat_sim_lsim = Y_lsim(:, n+1:2*n);
    x_rel_sim_lsim = Y_lsim(:, 2*n + 1);
    U_sim_lsim = Y_lsim(:, 2*n + 2);

    % Plot Step Response from lsim
    figure('Name', 'Step Response (using lsim)');
    subplot(3, 2, 1); plot(T_lsim, X_sim_lsim(:,1), 'b-', T_lsim, X_hat_sim_lsim(:,1), 'r--'); title('x_b'); legend('Actual', 'Est.'); grid on;
    subplot(3, 2, 2); plot(T_lsim, X_sim_lsim(:,2), 'b-', T_lsim, X_hat_sim_lsim(:,2), 'r--'); title('v_b'); legend('Actual', 'Est.'); grid on;
    subplot(3, 2, 3); plot(T_lsim, X_sim_lsim(:,3), 'b-', T_lsim, X_hat_sim_lsim(:,3), 'r--'); hold on; plot(T_lsim, R_lsim, 'k:'); title('x_t'); legend('Actual', 'Est.', 'Ref.'); grid on;
    subplot(3, 2, 4); plot(T_lsim, X_sim_lsim(:,4), 'b-', T_lsim, X_hat_sim_lsim(:,4), 'r--'); title('v_t'); legend('Actual', 'Est.'); grid on;
    subplot(3, 2, 5); plot(T_lsim, x_rel_sim_lsim, 'k-'); title('x_{rel}'); grid on; hold on; plot(T_lsim, zeros(size(T_lsim)), 'g:'); hold off; ylim([-0.1 0.1]);
    subplot(3, 2, 6); plot(T_lsim, U_sim_lsim, 'm-'); title('Control Input u=F'); grid on;
    sgtitle('Step Response of Table Position (using lsim)');
end


% --- Ensure previous required variables exist ---
% (Same as before, ensure A, B, C, K, L, n, etc. are defined)
if ~exist('K','var'); error('K not defined'); end
if ~exist('L','var'); error('L not defined'); end
% ... add checks or ensure the full script runs sequentially