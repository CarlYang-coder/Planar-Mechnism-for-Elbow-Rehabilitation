%% System Parameters
m = 0.5;      % Ball mass (kg)
M = 5.0;      % Table mass (kg)
k = 10;       % Spring stiffness (N/m)
c = 1;        % Damping coefficient (Ns/m)
b = 0.5;      % Friction coefficient (Ns/m)
eta = 0.7;    % Efficiency factor
r = 1;        % Lever arm (m)

% State-space matrices
A = [0, 1, 0, 0;
     -k/m, -(c+b)/m, k/m, (c+b)/m;
     0, 0, 0, 1;
     k/M, (c+b)/M, -k/M, -(c+b)/M];
B1 = [0; 0; 0; eta/(r*M)];
B2 = [0; 0; 0; eta/(r*M)];
C2 = eye(4); % Full-state output
D21 = zeros(4,1);

% H_infinity control parameters
rho = 0.1;    % Control input weight
C1 = [1, 0, -1, 0; 0, 0, 1, 0; 0, 0, 0, 0]; % Controlled output
D12 = [0; 0; rho];
p = size(B1,2); % Disturbance input dimension
q = size(C1,1); % Controlled output dimension
D11 = zeros(q, p); % Define D11 as a q x p zero matrix
n = size(A,1); % State dimension
m_in = size(B2,2); % Control input dimension
m_out = size(C2,1); % Output dimension

%% Bisection Setup
gamma_min = 1;    % Minimum gamma to test
gamma_max = 10000; % Maximum gamma
tol = 1e-3;       % Numerical tolerance
max_iter = 20;    % Maximum bisection iterations
gamma_opt = NaN;

for iter = 1:max_iter
    gamma_mid = (gamma_min + gamma_max) / 2;
    disp(['Iteration ', num2str(iter), ': Testing gamma = ', num2str(gamma_mid)]);

    %% CVX Setup
    cvx_begin sdp quiet
        variable Y(n,n) symmetric
        variable X(n,n) symmetric
        variable Ahat(n,n)
        variable Bhat(n,m_out)
        variable Chat(m_in,n)
        variable Dhat(m_in,m_out)
        minimize 0
        subject to
            % Constraint 1: LMI for H_infinity performance
            [A*Y + Y*A' + B2*Chat + Chat'*B2', (A*Y + B2*Chat)', (C1*Y + D12*Chat)', B1;
             A*Y + B2*Chat, A'*X + X*A + C2'*Bhat' + Bhat*C2, X*C1', X*B1;
             C1*Y + D12*Chat, C1, -gamma_mid*eye(q), D11;
             B1', (X*B1)', D11', -gamma_mid*eye(p)] <= -tol*eye(2*n + q + p)
            % Constraint 2: Coupling condition
            [Y, eye(n); eye(n), X] >= tol*eye(2*n)
    cvx_end

    % Check CVX status
    if strcmp(cvx_status, 'Solved')
        gamma_max = gamma_mid;
        gamma_opt = gamma_mid;
        disp(['Feasible gamma found: ', num2str(gamma_opt)]);
    else
        gamma_min = gamma_mid;
        disp('Infeasible, increasing gamma range.');
    end

    if (gamma_max - gamma_min) / gamma_max < tol
        break;
    end
end

if isnan(gamma_opt)
    error('No feasible gamma found within the given range.');
else
    disp(['Optimal gamma: ', num2str(gamma_opt)]);
end

%% Compute Controller Matrices with Optimal Gamma
cvx_begin sdp quiet
    variable Y(n,n) symmetric
    variable X(n,n) symmetric
    variable Ahat(n,n)
    variable Bhat(n,m_out)
    variable Chat(m_in,n)
    variable Dhat(m_in,m_out)
    minimize 0
    subject to
        [A*Y + Y*A' + B2*Chat + Chat'*B2', (A*Y + B2*Chat)', (C1*Y + D12*Chat)', B1;
         A*Y + B2*Chat, A'*X + X*A + C2'*Bhat' + Bhat*C2, X*C1', X*B1;
         C1*Y + D12*Chat, C1, -gamma_opt*eye(q), D11;
         B1', (X*B1)', D11', -gamma_opt*eye(p)] <= -tol*eye(2*n + q + p)
        [Y, eye(n); eye(n), X] >= tol*eye(2*n)
cvx_end

%% Compute Controller Matrices
AK = Ahat;
BK = Bhat;
CK = Chat;
DK = Dhat;

disp('Controller matrices:');
disp('A_K:'); disp(AK);
disp('B_K:'); disp(BK);
disp('C_K:'); disp(CK);
disp('D_K:'); disp(DK);

% Check for NaN/Inf in controller matrices
if any(isnan([AK(:); BK(:); CK(:); DK(:)]) | isinf([AK(:); BK(:); CK(:); DK(:)]))
    error('Controller matrices contain NaN or Inf.');
end

%% Closed-Loop System
Acl_approx = A - B2 * DK * C2; % Simplified closed-loop A matrix
Bcl = B1 - B2 * DK * D21;      % Closed-loop input matrix
Ccl = C1 - D12 * DK * C2;      % Closed-loop output matrix
Dcl = D11 - D12 * DK * D21;    % Closed-loop feedthrough (assumed zero if not specified)

% Create state-space model
sys_cl = ss(Acl_approx, Bcl, Ccl, Dcl);

%% Impulse Response Simulation
t = 0:0.01:5; % Time vector from 0 to 5 seconds with 0.01s steps
[y, t_out] = impulse(sys_cl, t); % Compute impulse response

%% Plot Impulse Response
figure;
plot(t_out, y(:,1));
title('Impulse Response of Closed-Loop System');
xlabel('Time (s)');
ylabel('Output');
grid on;
legend('Output 1');

%% Closed-Loop Stability Check
eig_Acl = eig(Acl_approx);
if all(real(eig_Acl) < 0)
    disp('Approximate closed-loop system is asymptotically stable.');
else
    warning('Approximate closed-loop system is not asymptotically stable.');
end
disp('Approximate closed-loop eigenvalues:'); disp(eig_Acl);

% Approximate H_infinity norm (optional recomputation)
try
    h_inf_norm = norm(sys_cl, inf);
    disp(['Approximate H_infinity norm: ', num2str(h_inf_norm)]);
    if h_inf_norm < gamma_opt
        disp(['H_infinity norm ', num2str(h_inf_norm), ' < gamma ', num2str(gamma_opt)]);
    else
        warning(['H_infinity norm ', num2str(h_inf_norm), ' >= gamma ', num2str(gamma_opt)]);
    end
catch e
    warning('Failed to compute H_infinity norm: %s', e.message);
end