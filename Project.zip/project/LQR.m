%% ========= 4. LQR =========
N  = 500;              
x0 = [0.5; 0; 0; 0];     

% Initialize
x = zeros(4,N+1);  x(:,1) = x0;
u = zeros(1,N);

% Simulation
for k = 1:N
    u(k)     = -K_inf * x(:,k);
    x(:,k+1) =  Ad * x(:,k) + Bd * u(k);
end


t  = (0:N) * Ts;
tu = (0:N-1) * Ts;

% plot
figure('Name','Infinite-horizon LQR, N=10000',...
       'Position',[200 80 720 520]);

% --- x₁ ---
subplot(3,1,1);
plot(t, x(1,:), 'b', 'LineWidth', 1.5);
ylabel('x_1 (ball - table)'); title('Relative displacement');
grid on;

% --- x₃ ---
subplot(3,1,2);
plot(t, x(3,:), 'g', 'LineWidth', 1.5);
ylabel('x_3 (table position)'); title('Table position');
grid on;

% --- u ---
subplot(3,1,3);
plot(tu, u, 'r', 'LineWidth', 1.5);
xlabel('Time (s)'); ylabel('u'); title('Control input');
grid on;