%% System Parameters
m = 0.5;      % Ball mass (kg)
M = 5.0;      % Table mass (kg)
k = 10;       % Spring stiffness (N/m)
c = 1;        % Damping coefficient (Ns/m)
b = 0.5;      % Friction coefficient (Ns/m)
eta = 0.7;    % Efficiency factor
r = 1;        % Lever arm (m)

% State-space matrices
A = [0, 1, 0, 0;
     -k/m, -(c+b)/m, k/m, (c+b)/m;
     0, 0, 0, 1;
     k/M, (c+b)/M, -k/M, -(c+b)/M];
B1 = [0; 0; 0; eta/(r*M)];
B2 = [0; 0; 0; eta/(r*M)];

% H_infinity control parameters
rho = 0.1;    % Control input weight
C1 = [1, 0, -1, 0; 0, 0, 1, 0; 0, 0, 0, 0]; % Controlled output
D12 = [0; 0; rho];
p = size(B1,2); % Disturbance input dimension
q = size(C1,1); % Controlled output dimension
D11 = zeros(q, p); % Corrected: Define D11 as a q x p zero matrix

% Dimensions
n = size(A,1); % State dimension
m_in = size(B2,2); % Control input dimension

%% Initial gamma value
gamma = 10;    % Initial guess for H_infinity norm bound
tol = 1e-3;    % Numerical tolerance for LMI

%% CVX Setup
cvx_solver sdpt3; % Use SDPT3 solver for robustness

%% CVX: State Feedback Gain F
disp('Solving for feedback gain F...');
cvx_begin sdp quiet
    variable Y(n,n) symmetric
    variable Z(m_in,n)
    variable gamma_var
    minimize gamma_var
    subject to
        % Y > 0 and LMI constraint
        Y == Y'
        Y >= tol*eye(n)
        [Y*A' + A*Y + Z'*B2' + B2*Z, B1, (C1*Y + D12*Z)';
         B1', -gamma_var*eye(size(B1,2)), D11';
         C1*Y + D12*Z, D11, -gamma_var*eye(size(C1,1))] <= -tol*eye(n + size(B1,2) + size(C1,1))
cvx_end

% Check CVX status
if ~strcmp(cvx_status, 'Solved')
    error('CVX failed to solve: %s', cvx_status);
end

% Feedback gain
F = Z / Y;
disp('Feedback gain F:'); disp(F);

% Check for NaN/Inf in F
if any(isnan(F(:)) | isinf(F(:)))
    error('Feedback gain F contains NaN or Inf.');
end

% Verify closed-loop stability
Acl = A - B2*F;
eig_Acl = eig(Acl);
if all(real(eig_Acl) < 0)
    disp('Closed-loop system (A - B2F) is asymptotically stable.');
else
    warning('Closed-loop system (A - B2F) is not asymptotically stable.');
end
disp('Closed-loop eigenvalues:'); disp(eig_Acl);

% Closed-Loop System for H_infinity norm
Bcl = B1;
Ccl = C1 - D12*F;

% Check for NaN/Inf in Acl
if any(isnan(Acl(:)) | isinf(Acl(:)))
    error('Closed-loop matrix Acl contains NaN or Inf.');
end

% H_infinity norm (approximate)
try
    sys_cl = ss(Acl, Bcl, Ccl, 0);
    h_inf_norm = norm(sys_cl, inf);
    disp(['Approximate H_infinity norm: ', num2str(h_inf_norm)]);
    if h_inf_norm < gamma_var
        disp(['H_infinity norm ', num2str(h_inf_norm), ' < gamma ', num2str(gamma_var)]);
    else
        warning(['H_infinity norm ', num2str(h_inf_norm), ' >= gamma ', num2str(gamma_var)]);
    end
catch e
    warning('Failed to compute H_infinity norm: %s', e.message);
end