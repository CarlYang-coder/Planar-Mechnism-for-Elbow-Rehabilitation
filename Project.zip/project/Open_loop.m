% --- 仿真: 开环系统脉冲响应 ---
fprintf('\n--- 仿真: 开环系统脉冲响应 ---\n');

% 创建开环系统对象 (如果尚未创建或已被覆盖)
% A, B, C, D 应该已经在工作区中定义
sys_ol = ss(A, B, C, D); 

% 定义仿真时间范围
t_sim_impulse = 0:0.01:15; % 可以根据需要调整仿真时长

% 使用 impulse 函数计算状态响应
% [y, t, x] = impulse(sys, T)
% y: 系统输出 C*x + D*u (我们这里主要关心 x)
% t: 时间向量
% x: 状态向量随时间的变化 (行是时间点，列是状态)
try
    [y_impulse, t_impulse, x_impulse] = impulse(sys_ol, t_sim_impulse);

    % 检查是否成功获取状态
    if isempty(x_impulse) || size(x_impulse, 2) ~= n
        error('未能从impulse函数获取状态信息。请检查系统定义。');
    end

    % 绘制四个状态的脉冲响应
    figure('Name', '开环系统脉冲响应 - 状态');

    subplot(2, 2, 1);
    plot(t_impulse, x_impulse(:, 1), 'b-');
    title('State 1: Ball Position (x_b)');
    xlabel('Time (s)');
    ylabel('Position (m)');
    grid on;

    subplot(2, 2, 2);
    plot(t_impulse, x_impulse(:, 2), 'r-');
    title('State 2: Ball Velocity (v_b)');
    xlabel('Time (s)');
    ylabel('Velocity (m/s)');
    grid on;

    subplot(2, 2, 3);
    plot(t_impulse, x_impulse(:, 3), 'g-');
    title('State 3: Table Position (x_t)');
    xlabel('Time (s)');
    ylabel('Position (m)');
    grid on;

    subplot(2, 2, 4);
    plot(t_impulse, x_impulse(:, 4), 'm-');
    title('State 4: Table Velocity (v_t)');
    xlabel('Time (s)');
    ylabel('Velocity (m/s)');
    grid on;

    sgtitle('Open-Loop Impulse Response - States'); % Add an overall title

catch ME_impulse
    fprintf('计算或绘制开环脉冲响应时出错: %s\n', ME_impulse.message);
end