%% CVX
% --- 系统参数定义 ---
m = 0.5;  % 小球质量 (kg)
M = 5.0;  % 桌子质量 (kg)
k = 10;   % 绳索弹性系数 (N/m)
c = 1;    % 绳索阻尼系数 (Ns/m)
b = 0.5;  % 桌面摩擦系数 (Ns/m)
eta = 0.7;
r = 1;

% --- 状态空间矩阵 ---
A = [ 0,        1,          0,         0;
     -k/m,  -(c+b)/m,      k/m,     (c+b)/m;
      0,        0,          0,         1;
      k/M,   (c+b)/M,     -k/M,    -(c+b)/M ];

B = [0; 0; 0; eta/(r*M)];

% 选择输出: y = [x_b - x_t; x_t]
C = [ 1, 0, -1, 0;
      0, 0,  1, 0 ];

D = [0; 0]; % 直接馈通矩阵

n = size(A, 1); % 系统阶数 (状态维度)
m_in = size(B, 2); % 输入维度
p = size(C, 1); % 输出维度

% 创建状态空间系统对象
sys = ss(A, B, C, D);
fprintf('系统阶数 n = %d\n', n);

% --- 分析 ---
fprintf('\n--- 系统分析 ---\n');
% 稳定性
fprintf('开环系统特征值 (稳定性):\n');
eig_A = eig(A);
disp(eig_A);
if any(real(eig_A) >= -1e-9)
    fprintf('开环系统不稳定或临界稳定。\n');
else
    fprintf('开环系统稳定。\n');
end

% 可控性
fprintf('\n可控性分析:\n');
Co = ctrb(A, B);
rank_Co = rank(Co);
fprintf('可控性矩阵秩: %d\n', rank_Co);
if rank_Co == n
    fprintf('系统完全可控。\n');
    fprintf('系统能稳。\n');
else
    fprintf('系统不可控。\n');
    fprintf('由于不可控，需要进一步分析能稳性。\n');
end

% 可观测性
fprintf('\n可观测性分析 (输出 y = [x_b-x_t; x_t]):\n');
Ob = obsv(A, C);
rank_Ob = rank(Ob);
fprintf('可观测性矩阵秩: %d\n', rank_Ob);
if rank_Ob == n
    fprintf('系统可观测。\n');
else
    fprintf('系统不可观测。\n');
end

% --- 控制器设计 (使用 CVX LMI) ---
fprintf('\n--- 使用 CVX LMI 设计状态反馈控制器 K ---\n');
K_lmi_ctrl = []; % Initialize K for LMI based controller

if rank_Co == n % 仅在系统可控时尝试设计
    epsilon = 1e-6;

    cvx_begin sdp % 使用 SDP 模式，显示求解过程
        % 定义 LMI 变量
        variable Q_cvx(n,n) symmetric % Q_cvx = P^-1 > 0
        variable Y_cvx(m_in, n)       % Y_cvx = K*Q_cvx

        % LMI 约束
        % 1. Q_cvx > 0
        Q_cvx >= epsilon * eye(n);

        % 2. A*Q_cvx + Q_cvx*A' - B*Y_cvx - Y_cvx'*B' < 0
        A*Q_cvx + Q_cvx*A' - B*Y_cvx - Y_cvx'*B' <= -epsilon * eye(n);
    cvx_end

    % 检查 CVX 求解状态
    if strfind(cvx_status, 'Solved')
        fprintf('CVX LMI 求解成功。\n');
        K_lmi_ctrl = Y_cvx / Q_cvx;
        fprintf('状态反馈增益 K (LMI):\n');
        disp(K_lmi_ctrl);
        Acl_lmi = A - B*K_lmi_ctrl;
        fprintf('闭环系统 (A-BK_lmi) 的特征值:\n');
        eig_Acl_lmi = eig(Acl_lmi);
        disp(eig_Acl_lmi);
        if all(real(eig_Acl_lmi) < 0)
             fprintf('LMI 控制器使闭环系统稳定。\n');
        else
             fprintf('警告: LMI 控制器未能使闭环系统稳定 (数值问题?)。\n');
             K_lmi_ctrl = [];
        end
    else
        fprintf('CVX LMI 求解失败。状态: %s\n', cvx_status);
        fprintf('无法使用 LMI 计算 K。\n');
        K_lmi_ctrl = [];
    end
else
    fprintf('系统不可控，无法保证使用 LMI 找到稳定化 K。\n');
    K_lmi_ctrl = [];
end

% --- 如果 LMI 失败或不可控，可以尝试使用 place (作为备选) ---
if isempty(K_lmi_ctrl) && rank_Co == n
    fprintf('\n--- LMI 失败，尝试使用 Place 设计控制器 K ---\n');
    P_ctrl_poles = [-1.0, -1.1, -1.5, -2.0]; % Renamed P_ctrl to P_ctrl_poles
    try
        K_place = place(A, B, P_ctrl_poles);
        fprintf('状态反馈增益 K (Place):\n');
        disp(K_place);
        Acl_place = A - B*K_place;
        fprintf('闭环系统 (A-BK_place) 的特征值:\n');
        disp(eig(Acl_place));
        K_lmi_ctrl = K_place; % Use K_place if LMI failed but place worked
    catch ME
        fprintf('无法使用 place 计算 K: %s\n', ME.message);
        K_lmi_ctrl = [];
    end
end

% --- 观测器设计 (使用 CVX LMI) ---
fprintf('\n--- 使用 CVX LMI 设计状态观测器 L ---\n');
L_lmi_obs = []; % Initialize L for LMI based observer
if rank_Ob == n
    epsilon = 1e-6; 

    cvx_begin sdp 
        variable Qo_cvx(n,n) symmetric 
        variable Yo_cvx(p, n)       
        Qo_cvx >= epsilon * eye(n);
        A'*Qo_cvx + Qo_cvx*A - C'*Yo_cvx - Yo_cvx'*C <= -epsilon * eye(n);
    cvx_end

    if strfind(cvx_status, 'Solved')
        fprintf('CVX LMI 求解成功 (观测器)。\n');
        L_lmi_obs = Qo_cvx \ Yo_cvx'; 
        fprintf('观测器增益 L (LMI):\n');
        disp(L_lmi_obs);
        Aobs_lmi = A - L_lmi_obs*C;
        fprintf('观测器误差动态 (A-LC) 的特征值:\n');
        eig_Aobs_lmi = eig(Aobs_lmi);
        disp(eig_Aobs_lmi);
         if all(real(eig_Aobs_lmi) < 0)
             fprintf('LMI 观测器使误差动态稳定。\n');
        else
             fprintf('警告: LMI 观测器未能使误差动态稳定 (数值问题?)。\n');
             L_lmi_obs = []; 
        end
    else
        fprintf('CVX LMI 求解失败 (观测器)。状态: %s\n', cvx_status);
        fprintf('无法使用 LMI 计算 L。\n');
        L_lmi_obs = [];
    end
else
     fprintf('系统不可观测，无法设计观测器。\n');
     L_lmi_obs = []; 
end

% --- 仿真 (LMI Observer-Controller) ---
if ~isempty(K_lmi_ctrl) && ~isempty(L_lmi_obs)
    fprintf('\n--- 仿真 (LMI Observer-Controller) ---\n');
    % For Simulink (if used)
    A_obs_sim = A - L_lmi_obs*C;
    B_obs_sim = [B, L_lmi_obs]; % Note: B_obs for simulink might be different depending on block
    C_obs_sim = eye(n);
    D_obs_sim = zeros(n, m_in + p);

    fprintf('Simulink Observer Matrices (for LMI controller):\n');
    fprintf('A_obs_sim:\n'); disp(A_obs_sim);
    fprintf('B_obs_sim:\n'); disp(B_obs_sim);
    fprintf('C_obs_sim:\n'); disp(C_obs_sim);
    fprintf('D_obs_sim:\n'); disp(D_obs_sim);
    fprintf('Gain K_lmi_ctrl:\n'); disp(K_lmi_ctrl);
    
    % MATLAB Simulation
    t_sim = 0:0.01:15;
    X0 = [0.5; 0; 0; 0]; % Actual initial state
    X0_hat = [0; 0; 0; 0]; % Initial state estimate

    ode_func_lmi = @(t, states) [
        A * states(1:n) + B * (-K_lmi_ctrl * states(n+1:2*n)); % Plant dynamics with u = -K*x_hat
        A * states(n+1:2*n) + B * (-K_lmi_ctrl * states(n+1:2*n)) + L_lmi_obs * (C * states(1:n) - C * states(n+1:2*n)); % Observer dynamics
    ];
    [T_lmi, STATES_lmi] = ode45(ode_func_lmi, t_sim, [X0; X0_hat]);
    X_sim_lmi = STATES_lmi(:, 1:n);
    X_hat_sim_lmi = STATES_lmi(:, n+1:2*n);
    U_sim_lmi = (-K_lmi_ctrl * X_hat_sim_lmi')'; % Control input u = -K*x_hat
    x_rel_sim_lmi = X_sim_lmi(:,1) - X_sim_lmi(:,3);

     figure('Name', 'LMI Observer-Controller Simulation');
     subplot(3, 2, 1); plot(T_lmi, X_sim_lmi(:,1), 'b-', T_lmi, X_hat_sim_lmi(:,1), 'r--'); title('Ball Position x_b'); legend('Actual', 'Estimated'); grid on;
     subplot(3, 2, 2); plot(T_lmi, X_sim_lmi(:,2), 'b-', T_lmi, X_hat_sim_lmi(:,2), 'r--'); title('Ball Velocity v_b'); legend('Actual', 'Estimated'); grid on;
     subplot(3, 2, 3); plot(T_lmi, X_sim_lmi(:,3), 'b-', T_lmi, X_hat_sim_lmi(:,3), 'r--'); title('Table Position x_t'); legend('Actual', 'Estimated'); grid on;
     subplot(3, 2, 4); plot(T_lmi, X_sim_lmi(:,4), 'b-', T_lmi, X_hat_sim_lmi(:,4), 'r--'); title('Table Velocity v_t'); legend('Actual', 'Estimated'); grid on;
     subplot(3, 2, 5); plot(T_lmi, x_rel_sim_lmi, 'k-'); title('Relative Position x_{rel}'); hold on; plot(T_lmi, zeros(size(T_lmi)), 'g:'); hold off; grid on;
     subplot(3, 2, 6); plot(T_lmi, U_sim_lmi, 'm-'); title('Control Input F (LMI)'); grid on; 
     
     figure('Name', 'LMI Estimation Error'); 
     plot(T_lmi, X_sim_lmi - X_hat_sim_lmi); title('State Estimation Error (X - X_{hat}) (LMI)'); legend('e_{xb}', 'e_{vb}', 'e_{xt}', 'e_{vt}'); grid on;
else
    fprintf('\nLMI controller or LMI observer未能成功设计，无法进行LMI部分的仿真。\n');
    % Ensure variables exist for Simulink if it expects them, even if empty/NaN
    if ~exist('K_lmi_ctrl','var') || isempty(K_lmi_ctrl); K_lmi_ctrl = nan(m_in, n); end
    if ~exist('L_lmi_obs','var') || isempty(L_lmi_obs); L_lmi_obs = nan(n, p); end
    if ~exist('A_obs_sim','var'); A_obs_sim = nan(n, n); end
    if ~exist('B_obs_sim','var'); B_obs_sim = nan(n, m_in+p); end
    if ~exist('C_obs_sim','var'); C_obs_sim = nan(n, n); end
    if ~exist('D_obs_sim','var'); D_obs_sim = nan(n, m_in+p); end
end

% 确保 X0 和 X0_hat 总是存在 (for other parts of script or Simulink)
if ~exist('X0','var'); X0 = zeros(n,1); end
if ~exist('X0_hat','var'); X0_hat = zeros(n,1); end


% --- H2 控制器设计 ---
fprintf('\n--- H2 控制器设计 ---\n');
K_h2 = []; % Initialize H2 controller
GAM_h2 = inf;

if rank_Co == n && rank_Ob == n
    fprintf('系统可控且可观测，尝试设计H2控制器。\n');
    
    % H2 控制器参数
    w_xrel = 1.0;      % Weight for relative position x_b - x_t
    w_xt = 5; 
    rho_h2 = 0.01;     % Control effort penalty (w_u^2 = rho_h2)
    w_u = sqrt(rho_h2);

    % 定义广义对象 P(s) 的状态空间矩阵
    % dx/dt = A x + Bw w + Bu u
    % z     = Cz x + Dzw w + Dzu u
    % y     = Cy x + Dyw w + Dyu u

    Bw = B; % Disturbance w enters through B
    Bu = B; % Control u enters through B

    % Cz defines regulated outputs z = [w_xrel*(xb-xt); w_u*u]
    % First part from state: w_xrel * C(1,:) * x
    % Second part from input u: w_u * u
    Cz_h2 = [w_xrel * C(1,:);    % For w_xrel*(xb-xt)
             w_xt * [0 0 1 0];   % Placeholder for w_u*u (comes from Dzu)
             zeros(m_in, n)]; 
    
    Dzw_h2 = [zeros(1, size(Bw,2));         % w_xrel*(xb-xt) not directly affected by w
              zeros(1, size(Bw,2));    % w_u*u not directly affected by w
              zeros(m_in, size(Bw,2))];
    
    Dzu_h2 = [zeros(1, m_in);               % w_xrel*(xb-xt) not directly affected by u
              zeros(1, m_in);            % w_u*u directly from u
              w_u * eye(m_in)];

    Cy_h2 = C; % Measured outputs y = [xb-xt; xt]
    Dyw_h2 = zeros(p, size(Bw,2)); % y not directly affected by w
    Dyu_h2 = D; % Original D matrix for y from u (is zeros)

    % Form the generalized plant P for h2syn
    % Inputs to P are [w; u], outputs from P are [z; y]
    % Number of disturbance inputs nw = size(Bw,2)
    % Number of control inputs nu = size(Bu,2)
    % Number of regulated outputs nz = size(Cz_h2,1)
    % Number of measured outputs ny = size(Cy_h2,1)

    B_generalized = [Bw, Bu];
    C_generalized = [Cz_h2; Cy_h2];
    D_generalized = [Dzw_h2, Dzu_h2; Dyw_h2, Dyu_h2];
    
    P_h2 = ss(A, B_generalized, C_generalized, D_generalized);
    
    nmeas = p; % Number of measurements (outputs to controller)
    ncont = m_in; % Number of controls (inputs from controller)
    
    try
        [K_h2, CL_h2_perf, GAM_h2] = h2syn(P_h2, nmeas, ncont);
        fprintf('H2 控制器设计成功。\n');
        fprintf('获得的 H2 范数 GAM_h2 = %f\n', GAM_h2);
        disp('H2 控制器 K_h2:');
        disp(K_h2);
        
        % 检查闭环稳定性 (K_h2 is an output feedback controller)
        sys_plant_orig = ss(A,B,C,D);
        sys_cl_h2_check = feedback(sys_plant_orig, K_h2); % Assumes K_h2 for u = -K*y
                                                         % h2syn produces K for u = K*y.
                                                         % For loop G -> K -> G (pos feedback at G input): (I-GK)^-1 G
                                                         % feedback(G,K) is G(I+KG)^-1 (neg feedback)
                                                         % feedback(G,K, +1) is G(I-KG)^-1 (pos feedback)
        % h2syn controllers are typically applied in negative feedback u = -K_h2*y_meas.
        % However, the Robust Control Toolbox's syn functions (hinfysn, h2syn)
        % often return K such that u = K*y.
        % If u = K*y, then feedback(PLANT, K) implies summing junction r-y_f, u = K*(r-y_f)
        % Let's check poles of A_cl = A-BK_h2 if K_h2 were static gain (not the case).
        % The CL_h2_perf object is the closed loop from w to z. Its poles are the closed-loop poles.
        fprintf('H2 闭环系统 (w to z) 特征值:\n');
        eig_cl_h2 = pole(CL_h2_perf);
        disp(eig_cl_h2);
        if all(real(eig_cl_h2) < 0)
            fprintf('H2 控制器使闭环系统稳定。\n');
        else
            fprintf('警告: H2 控制器未能使闭环系统稳定。\n');
            K_h2 = []; % Invalidate controller
        end

    catch ME
        fprintf('H2 控制器设计失败: %s\n', ME.message);
        K_h2 = [];
    end
else
    fprintf('系统不可控或不可观测，无法设计H2控制器。\n');
    K_h2 = [];
end


% --- 仿真 (H2 Controller) ---
if ~isempty(K_h2)
    fprintf('\n--- 仿真 (H2 Controller) ---\n');
    
    sys_plant_for_h2_sim = ss(A, B, C, D); % Plant G
    
    % K_h2 controller from h2syn is designed for u = K_h2 * y
    % The feedback command feedback(G,K) forms G/(I+GK) (negative feedback)
    % So if u = K_h2 * y, and this u is fed to plant: y = G*u_actual
    % u_actual = u_external - K_h2*y (standard negative feedback structure)
    % If u_external = 0, then u_actual = -K_h2*y.
    % So, we use K_h2 directly in the feedback command.
    sys_cl_h2_sim = feedback(sys_plant_for_h2_sim, K_h2);
    
    t_sim = 0:0.01:15; % Re-use t_sim or define new if needed
    % Initial condition for plant X0 is already defined
    % Initial condition for controller states (assuming K_h2 is not static)
    if ~isa(K_h2, 'double') % If K_h2 is a state-space object
        X0_controller_h2 = zeros(size(K_h2.A,1),1);
    else % K_h2 is a static gain
        X0_controller_h2 = []; % No controller states
    end
    X0_h2_augmented = [X0; X0_controller_h2];

    % Simulate the closed-loop system response to initial conditions
    % lsim provides states of the closed-loop system.
    % initial() is more direct for zero input response.
    % [Y_h2_sim, T_h2_sim, X_aug_h2_sim] = lsim(sys_cl_h2_sim, zeros(size(t_sim)), t_sim, X0_h2_augmented);
    [~, T_h2_sim, X_aug_h2_sim] = initial(sys_cl_h2_sim, X0_h2_augmented, t_sim);
    
    X_plant_sim_h2 = X_aug_h2_sim(:, 1:n);
    if ~isempty(X0_controller_h2)
        X_ctrl_sim_h2  = X_aug_h2_sim(:, n+1:end);
    else
        X_ctrl_sim_h2 = []; % Empty if static gain
    end

    % Reconstruct control input u = K_h2 * y_plant_measured
    % y_plant_measured = C * x_plant + D * u
    % u = Ck*xc + Dk*y_plant_measured
    % u = Ck*xc + Dk*(C*x_plant + D*u)
    % (I - Dk*D)*u = Ck*xc + Dk*C*x_plant
    % u = inv(I - Dk*D) * (Ck*xc + Dk*C*x_plant)
    
    U_sim_h2 = zeros(length(T_h2_sim), m_in);
    if isa(K_h2, 'double') % Static gain K_h2
        Y_plant_measured_sim_h2 = (C * X_plant_sim_h2')'; % Assuming D=0
        U_sim_h2 = (-K_h2 * Y_plant_measured_sim_h2')'; % u = -K*y if K is gain matrix
    else % Dynamic controller K_h2 = ss(Ak,Bk,Ck,Dk)
        inv_term = eye(m_in); % Default if Dk or D is zero
        if any(any(K_h2.D)) && any(any(D))
            inv_term = inv(eye(m_in) - K_h2.D * D);
        elseif any(any(K_h2.D)) && ~any(any(D)) % D is zero
             % No change needed for inv_term, it's I
        end

        for k_loop = 1:length(T_h2_sim)
            xp_k = X_plant_sim_h2(k_loop,:)';
            if ~isempty(X_ctrl_sim_h2)
                xc_k = X_ctrl_sim_h2(k_loop,:)';
            else
                xc_k = []; % Should not happen if K_h2 is ss and X_ctrl_sim_h2 is not empty
            end
            
            % y_measured_k = C*xp_k + D*u_k; % This D is plant D.
            % Since u_k is what we are calculating, use the y output from lsim/initial if available
            % Or, reconstruct y from states assuming u is part of closed loop calculation
            % y_measured_k for controller input K_h2.D * (C*xp_k).
            % The controller structure is u = K_h2.C * xc_k + K_h2.D * (C*xp_k + D*u_prev)
            % This reconstruction is easier if D (plant D) is zero.
            if ~any(any(D))
                term_Dk_C_xp = K_h2.D * C * xp_k;
            else
                % This is complex due to algebraic loop if D and K_h2.D are non-zero.
                % `feedback` command handles this internally.
                % A simpler way: use the output Y_h2_sim from lsim if lsim was configured to output y.
                % For now, assume D=0 for simplicity in u reconstruction if K_h2.D is non-zero.
                % If D is not zero and K_h2.D is not zero, this reconstruction is tricky.
                % However, our D IS ZERO.
                term_Dk_C_xp = K_h2.D * C * xp_k; % D is zero, so y = C*xp_k
            end
            
            if ~isempty(X_ctrl_sim_h2)
                 U_sim_h2(k_loop,:) = (inv_term * (K_h2.C * xc_k + term_Dk_C_xp))';
            else % K_h2 is just a gain matrix. What does h2syn return? A state-space object.
                 % This case should not be hit if K_h2 is from h2syn.
                 % If h2syn returned a gain matrix K, then u = -K*y.
                 % y = C*xp_k (since D=0). So u = -K*C*xp_k.
                 % U_sim_h2(k_loop,:) = (-K_h2 * C * xp_k)';
                 % This path is unlikely for h2syn.
            end
        end
    end
    
    x_rel_sim_h2 = X_plant_sim_h2(:,1) - X_plant_sim_h2(:,3);

    figure('Name', 'H2 Controller Simulation');
    subplot(3,2,1); plot(T_h2_sim, X_plant_sim_h2(:,1), 'b-'); title('Ball Position x_b (H2)'); grid on;
    subplot(3,2,2); plot(T_h2_sim, X_plant_sim_h2(:,2), 'b-'); title('Ball Velocity v_b (H2)'); grid on;
    subplot(3,2,3); plot(T_h2_sim, X_plant_sim_h2(:,3), 'b-'); title('Table Position x_t (H2)'); grid on;
    subplot(3,2,4); plot(T_h2_sim, X_plant_sim_h2(:,4), 'b-'); title('Table Velocity v_t (H2)'); grid on;
    subplot(3,2,5); plot(T_h2_sim, x_rel_sim_h2, 'k-'); title('Relative Position x_{rel} (H2)'); hold on; plot(T_h2_sim, zeros(size(T_h2_sim)), 'g:'); hold off; grid on;
    subplot(3,2,6); plot(T_h2_sim, U_sim_h2, 'm-'); title('Control Input F (H2)'); grid on;

    % If K_h2 has states, we can plot them too
    if ~isempty(X0_controller_h2) && ~isempty(X_ctrl_sim_h2)
        figure('Name', 'H2 Controller States');
        num_ctrl_states = size(X_ctrl_sim_h2, 2);
        for i = 1:num_ctrl_states
            subplot(ceil(num_ctrl_states/2), 2, i);
            plot(T_h2_sim, X_ctrl_sim_h2(:,i));
            title(sprintf('H2 Controller State x_{c%d}', i));
            grid on;
        end
    end

else
    fprintf('\nH2 controller未能成功设计，无法进行H2仿真。\n');
end

% --- Final check on variable existence for Simulink ---
% (If you plan to use these in a Simulink model that runs after this script)
if ~exist('K','var'); K = nan(m_in,n); end % K from LMI/place state feedback
if ~exist('L','var'); L = nan(n,p); end % L from LMI observer
% For H2 controller, K_h2 is the ss object.
% For Simulink, you'd typically pass A,B,C,D of plant and K_h2 itself.

%% System Parameters
m = 0.5;      % Ball mass (kg)
M = 5.0;      % Table mass (kg)
k = 10;       % Spring stiffness (N/m)
c = 1;        % Damping coefficient (Ns/m)
b = 0.5;      % Friction coefficient (Ns/m)
eta = 0.7;    % Efficiency factor
r = 1;        % Lever arm (m)

% State-space matrices
A = [0, 1, 0, 0;
     -k/m, -(c+b)/m, k/m, (c+b)/m;
     0, 0, 0, 1;
     k/M, (c+b)/M, -k/M, -(c+b)/M];
B = [0; 0; 0; eta/(r*M)];

% H2 control parameters
rho = 0.1;    % Control input weight
C1 = [1, 0, -1, 0; 0, 0, 1, 0; 0, 0, 0, 0]; % Controlled output
D12 = [0; 0; rho];
B1 = B;       % Disturbance input

% Dimensions
n = size(A,1); % State dimension
m_in = size(B,2); % Input dimension
q = size(C1,1); % Controlled output dimension

% Constraints
tol = 1e-3;   % Numerical tolerance for LMI

% CVX Setup
cvx_solver sdpt3; % Use SDPT3 solver for robustness

% CVX: State Feedback Gain K
disp('Solving for feedback gain K...');
cvx_begin sdp quiet
    variable X(n,n) symmetric
    variable Y(m_in,n)
    variable Z(q,q) symmetric
    minimize trace(Z)
    subject to
        % Constraint 1: X is symmetric positive definite
        X = X';
        X > tol*eye(n);
        % Constraint 2: Stability LMI
        A*X + X*A' - B*Y - Y'*B' <= -tol*eye(n);
        % Constraint 3: H2 performance
        [Z, (C1 - D12*Y)*X; (C1 - D12*Y)'*X, X] >= tol*eye(q+n);
cvx_end

% Check CVX status
if ~strcmp(cvx_status, 'Solved')
    error('CVX failed to solve: %s', cvx_status);
end

% Feedback gain
K = Y / X;
disp('Feedback gain K:'); disp(K);

% Check for NaN/Inf in K
if any(isnan(K(:)) | isinf(K(:)))
    error('Feedback gain K contains NaN or Inf.');
end

% Verify closed-loop stability
Acl = A - B*K;
eig_Acl = eig(Acl);
if all(real(eig_Acl) < 0)
    disp('Closed-loop system (A - BK) is asymptotically stable.');
else
    warning('Closed-loop system (A - BK) is not asymptotically stable.');
end
disp('Closed-loop eigenvalues:'); disp(eig_Acl);

% Closed-Loop System for H2 norm
Bcl = B1;
Ccl = C1 - D12*K;

% Check for NaN/Inf in Acl
if any(isnan(Acl(:)) | isinf(Acl(:)))
    error('Closed-loop matrix Acl contains NaN or Inf.');
end

% H2 norm (approximate)
try
    sys_cl = ss(Acl, Bcl, Ccl, zeros(q,m_in));
    h2_norm = norm(sys_cl, 2);
    disp(['Approximate H2 norm: ', num2str(h2_norm)]);
catch e
    warning('Failed to compute H2 norm: %s', e.message);
end