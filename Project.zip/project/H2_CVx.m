% H2 Controller Design with CVX for Ball-Table System
% System: Ball and table connected by spring and damper
% Constraints: Gain limits and pole placement
% Updated to fix CVX unbounded error for filter gain L

clear; clc;

%% System Parameters
m = 0.5;      % Ball mass (kg)
M = 5.0;      % Table mass (kg)
k = 10;       % Spring stiffness (N/m)
c = 1;        % Damping coefficient (Ns/m)
b = 0.5;      % Friction coefficient (Ns/m)
eta = 0.7;    % Efficiency factor
r = 1;        % Lever arm (m)

% State-space matrices
A = [0, 1, 0, 0;
     -k/m, -(c+b)/m, k/m, (c+b)/m;
     0, 0, 0, 1;
     k/M, (c+b)/M, -k/M, -(c+b)/M];
B = [0; 0; 0; eta/(r*M)];
C = [1, 0, -1, 0;
     0, 0, 1, 0];
D = [0; 0];

% H2 control parameters
rho = 0.1;    % Control input weight
sigma = 0.05; % Measurement noise intensity (increased)
C1 = [C; zeros(1,4)]; % Controlled output: [x_b - x_t; x_t; 0]
D12 = [0; 0; rho];
B1 = B;       % Disturbance input same as control input
C2 = C;
D21 = [sigma; sigma];

% Dimensions
n = size(A,1); % State dimension
m_in = size(B,2); % Input dimension
p = size(C,1); % Output dimension
q = size(C1,1); % Controlled output dimension

%% Constraints
kappa = 200;  % Feedback gain norm limit
lambda = 500; % Filter gain norm limit (relaxed)
alpha = 0.2;  % Pole placement: Re(s) < -alpha (relaxed)
tol = 1e-3;   % Numerical tolerance for LMI (increased)

%% CVX Setup
cvx_solver sdpt3; % Use SDPT3 solver for robustness

%% CVX: State Feedback Gain K
disp('Solving for feedback gain K...');
cvx_begin sdp quiet
    variable X(n,n) symmetric
    variable Y(m_in,n)
    variable Z(q,q) symmetric
    minimize trace(Z)
    subject to
        % Stability and H2 performance
        [A*X + X*A' - B*Y - Y'*B', B1; B1', -eye(m_in)] <= -tol*eye(n+m_in);
        [Z, C1*X - D12*Y; (C1*X - D12*Y)', X] >= tol*eye(q+n);
        X >= tol*eye(n);
        % Gain constraint: ||K||_2 <= kappa
        [kappa^2*eye(m_in), Y; Y', X] >= tol*eye(m_in+n);
        % Pole placement: Re(s) < -alpha
        A*X + X*A' - B*Y - Y'*B' + 2*alpha*X <= -tol*eye(n);
cvx_end

% Check CVX status
if ~strcmp(cvx_status, 'Solved')
    error('CVX failed to solve for K: %s', cvx_status);
end

% Feedback gain
K = Y / X;
disp('Feedback gain K:'); disp(K);

% Check for NaN/Inf in K
if any(isnan(K(:)) | isinf(K(:)))
    error('Feedback gain K contains NaN or Inf.');
end

% Verify closed-loop stability
Acl = A - B*K;
eig_Acl = eig(Acl);
if all(real(eig_Acl) < 0)
    disp('Closed-loop system (A - BK) is stable.');
else
    warning('Closed-loop system (A - BK) is not stable.');
end
disp('Closed-loop eigenvalues (A - BK):'); disp(eig_Acl);

% Check gain constraint
norm_K = norm(full(K), 2);
if norm_K <= kappa
    disp(['Feedback gain norm: ', num2str(norm_K), ' <= ', num2str(kappa)]);
else
    warning(['Feedback gain norm: ', num2str(norm_K), ' > ', num2str(kappa)]);
end

%% CVX: Kalman Filter Gain L
disp('Solving for filter gain L...');
cvx_begin sdp quiet
    variable Y(n,n) symmetric
    variable W(n,p)
    variable V(n,n) symmetric
    minimize trace(V)
    subject to
        % Stability and H2 performance
        [Y*A + A'*Y - W*C2 - C2'*W', Y*B1 - W*D21; (Y*B1 - W*D21)', -eye(m_in)] <= -1e-3*eye(n+m_in);
        Y >= 1e-3*eye(n);
        % Gain constraint: ||L||_2 <= lambda
        [lambda^2*eye(p), W'; W, Y] >= 1e-3*eye(p+n);
        % Pole placement: Re(s) < -alpha
        Y*A + A'*Y - W*C2 - C2'*W' + 2*alpha*Y <= -1e-3*eye(n);
        % Bound V to prevent unboundedness
        V <= 1e-3*eye(n);
cvx_end

% Check CVX status
if ~strcmp(cvx_status, 'Solved')
    error('CVX failed to solve for L: %s', cvx_status);
end

% Filter gain
L = Y \ W;
disp('Filter gain L:'); disp(L);

% Check for NaN/Inf in L
if any(isnan(L(:)) | isinf(L(:)))
    error('Filter gain L contains NaN or Inf.');
end

% Verify filter stability
Afl = A - L*C2;
eig_Afl = eig(Afl);
if all(real(eig_Afl) < 0)
    disp('Filter system (A - LC2) is stable.');
else
    warning('Filter system (A - LC2) is not stable.');
end
disp('Filter eigenvalues (A - LC2):'); disp(eig_Afl);

% Check gain constraint
norm_L = norm(full(L), 2);
if norm_L <= lambda
    disp(['Filter gain norm: ', num2str(norm_L), ' <= ', num2str(lambda)]);
else
    warning(['Filter gain norm: ', num2str(norm_L), ' > ', num2str(lambda)]);
end

%% Controller Synthesis
Ac = A - B*K - L*C2;
Bc = L;
Cc = -K;

% Check for NaN/Inf in controller matrices
if any(isnan(Ac(:)) | isinf(Ac(:))) || any(isnan(Bc(:)) | isinf(Bc(:))) || any(isnan(Cc(:)) | isinf(Cc(:)))
    error('Controller matrices contain NaN or Inf.');
end

disp('Controller matrices:');
disp('Ac = '); disp(Ac);
disp('Bc = '); disp(Bc);
disp('Cc = '); disp(Cc);

%% Closed-Loop System
Acl = [A, B*Cc; Bc*C2, Ac];
Bcl = [B1; Bc*D21];
Ccl = [C1, D12*Cc];

% Check for NaN/Inf in Acl
if any(isnan(Acl(:)) | isinf(Acl(:)))
    error('Closed-loop matrix Acl contains NaN or Inf.');
end

% Verify closed-loop stability
eig_cl = eig(Acl);
if all(real(eig_cl) < 0)
    disp('Closed-loop system is stable.');
else
    warning('Closed-loop system is not stable.');
end
disp('Closed-loop eigenvalues:'); disp(eig_cl);

% H2 norm (approximate)
try
    sys_cl = ss(Acl, Bcl, Ccl, zeros(q,m_in));
    h2_norm = norm(sys_cl, 2);
    disp(['Approximate H2 norm: ', num2str(h2_norm)]);
catch e
    warning('Failed to compute H2 norm: %s', e.message);
end