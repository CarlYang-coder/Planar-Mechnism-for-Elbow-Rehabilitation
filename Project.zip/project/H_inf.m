%% CVX
% --- 系统参数定义 ---
m = 0.5;  % 小球质量 (kg)
M = 5.0;  % 桌子质量 (kg)
k = 10;   % 绳索弹性系数 (N/m)
c = 1;    % 绳索阻尼系数 (Ns/m)
b = 0.5;  % 桌面摩擦系数 (Ns/m)
eta = 0.7;
r = 1;

% --- 状态空间矩阵 ---
A = [ 0,        1,          0,         0;
     -k/m,  -(c+b)/m,      k/m,     (c+b)/m;
      0,        0,          0,         1;
      k/M,   (c+b)/M,     -k/M,    -(c+b)/M ];

B = [0; 0; 0; eta/(r*M)];

% 选择输出: y = [x_b - x_t; x_t]
C = [ 1, 0, -1, 0;
      0, 0,  1, 0 ];

D = [0; 0]; % 直接馈通矩阵

n = size(A, 1); % 系统阶数 (状态维度)
m_in = size(B, 2); % 输入维度
p = size(C, 1); % 输出维度

% 创建状态空间系统对象
sys = ss(A, B, C, D);
fprintf('系统阶数 n = %d\n', n);

% --- 分析 ---
fprintf('\n--- 系统分析 ---\n');
% 稳定性
fprintf('开环系统特征值 (稳定性):\n');
eig_A = eig(A);
disp(eig_A);
if any(real(eig_A) >= -1e-9)
    fprintf('开环系统不稳定或临界稳定。\n');
else
    fprintf('开环系统稳定。\n');
end

% 可控性
fprintf('\n可控性分析:\n');
Co = ctrb(A, B);
rank_Co = rank(Co);
fprintf('可控性矩阵秩: %d\n', rank_Co);
if rank_Co == n
    fprintf('系统完全可控。\n');
    fprintf('系统能稳。\n');
else
    fprintf('系统不可控。\n');
    fprintf('由于不可控，需要进一步分析能稳性。\n');
end

% 可观测性
fprintf('\n可观测性分析 (输出 y = [x_b-x_t; x_t]):\n');
Ob = obsv(A, C);
rank_Ob = rank(Ob);
fprintf('可观测性矩阵秩: %d\n', rank_Ob);
if rank_Ob == n
    fprintf('系统可观测。\n');
else
    fprintf('系统不可观测。\n');
end

% --- 控制器设计 (使用 CVX LMI) ---
fprintf('\n--- 使用 CVX LMI 设计状态反馈控制器 K ---\n');
K_lmi_ctrl = []; % Initialize K for LMI based controller

if rank_Co == n % 仅在系统可控时尝试设计
    epsilon = 1e-6;

    cvx_begin sdp % 使用 SDP 模式，显示求解过程
        % 定义 LMI 变量
        variable Q_cvx(n,n) symmetric % Q_cvx = P^-1 > 0
        variable Y_cvx(m_in, n)       % Y_cvx = K*Q_cvx

        % LMI 约束
        % 1. Q_cvx > 0
        Q_cvx >= epsilon * eye(n);

        % 2. A*Q_cvx + Q_cvx*A' - B*Y_cvx - Y_cvx'*B' < 0
        A*Q_cvx + Q_cvx*A' - B*Y_cvx - Y_cvx'*B' <= -epsilon * eye(n);
    cvx_end

    % 检查 CVX 求解状态
    if strfind(cvx_status, 'Solved')
        fprintf('CVX LMI 求解成功。\n');
        K_lmi_ctrl = Y_cvx / Q_cvx;
        fprintf('状态反馈增益 K (LMI):\n');
        disp(K_lmi_ctrl);
        Acl_lmi = A - B*K_lmi_ctrl;
        fprintf('闭环系统 (A-BK_lmi) 的特征值:\n');
        eig_Acl_lmi = eig(Acl_lmi);
        disp(eig_Acl_lmi);
        if all(real(eig_Acl_lmi) < 0)
             fprintf('LMI 控制器使闭环系统稳定。\n');
        else
             fprintf('警告: LMI 控制器未能使闭环系统稳定 (数值问题?)。\n');
             K_lmi_ctrl = [];
        end
    else
        fprintf('CVX LMI 求解失败。状态: %s\n', cvx_status);
        fprintf('无法使用 LMI 计算 K。\n');
        K_lmi_ctrl = [];
    end
else
    fprintf('系统不可控，无法保证使用 LMI 找到稳定化 K。\n');
    K_lmi_ctrl = [];
end

% --- 如果 LMI 失败或不可控，可以尝试使用 place (作为备选) ---
if isempty(K_lmi_ctrl) && rank_Co == n
    fprintf('\n--- LMI 失败，尝试使用 Place 设计控制器 K ---\n');
    P_ctrl_poles = [-1.0, -1.1, -1.5, -2.0]; % Renamed P_ctrl to P_ctrl_poles
    try
        K_place = place(A, B, P_ctrl_poles);
        fprintf('状态反馈增益 K (Place):\n');
        disp(K_place);
        Acl_place = A - B*K_place;
        fprintf('闭环系统 (A-BK_place) 的特征值:\n');
        disp(eig(Acl_place));
        K_lmi_ctrl = K_place; % Use K_place if LMI failed but place worked
    catch ME
        fprintf('无法使用 place 计算 K: %s\n', ME.message);
        K_lmi_ctrl = [];
    end
end

% --- 观测器设计 (使用 CVX LMI) ---
fprintf('\n--- 使用 CVX LMI 设计状态观测器 L ---\n');
L_lmi_obs = []; % Initialize L for LMI based observer
if rank_Ob == n
    epsilon = 1e-6; 

    cvx_begin sdp 
        variable Qo_cvx(n,n) symmetric 
        variable Yo_cvx(p, n)       
        Qo_cvx >= epsilon * eye(n);
        A'*Qo_cvx + Qo_cvx*A - C'*Yo_cvx - Yo_cvx'*C <= -epsilon * eye(n);
    cvx_end

    if strfind(cvx_status, 'Solved')
        fprintf('CVX LMI 求解成功 (观测器)。\n');
        L_lmi_obs = Qo_cvx \ Yo_cvx'; 
        fprintf('观测器增益 L (LMI):\n');
        disp(L_lmi_obs);
        Aobs_lmi = A - L_lmi_obs*C;
        fprintf('观测器误差动态 (A-LC) 的特征值:\n');
        eig_Aobs_lmi = eig(Aobs_lmi);
        disp(eig_Aobs_lmi);
         if all(real(eig_Aobs_lmi) < 0)
             fprintf('LMI 观测器使误差动态稳定。\n');
        else
             fprintf('警告: LMI 观测器未能使误差动态稳定 (数值问题?)。\n');
             L_lmi_obs = []; 
        end
    else
        fprintf('CVX LMI 求解失败 (观测器)。状态: %s\n', cvx_status);
        fprintf('无法使用 LMI 计算 L。\n');
        L_lmi_obs = [];
    end
else
     fprintf('系统不可观测，无法设计观测器。\n');
     L_lmi_obs = []; 
end

% --- 仿真 (LMI Observer-Controller) ---
if ~isempty(K_lmi_ctrl) && ~isempty(L_lmi_obs)
    fprintf('\n--- 仿真 (LMI Observer-Controller) ---\n');
    % For Simulink (if used)
    A_obs_sim = A - L_lmi_obs*C;
    B_obs_sim = [B, L_lmi_obs]; 
    C_obs_sim = eye(n);
    D_obs_sim = zeros(n, m_in + p);

    fprintf('Simulink Observer Matrices (for LMI controller):\n');
    fprintf('A_obs_sim:\n'); disp(A_obs_sim);
    fprintf('B_obs_sim:\n'); disp(B_obs_sim);
    fprintf('C_obs_sim:\n'); disp(C_obs_sim);
    fprintf('D_obs_sim:\n'); disp(D_obs_sim);
    fprintf('Gain K_lmi_ctrl:\n'); disp(K_lmi_ctrl);
    
    t_sim_lmi = 0:0.01:15; % Renamed t_sim to t_sim_lmi
    X0 = [0.5; 0; 0; 0]; 
    X0_hat = [0; 0; 0; 0]; 

    ode_func_lmi = @(t, states) [
        A * states(1:n) + B * (-K_lmi_ctrl * states(n+1:2*n)); 
        A * states(n+1:2*n) + B * (-K_lmi_ctrl * states(n+1:2*n)) + L_lmi_obs * (C * states(1:n) - C * states(n+1:2*n)); 
    ];
    [T_lmi, STATES_lmi] = ode45(ode_func_lmi, t_sim_lmi, [X0; X0_hat]);
    X_sim_lmi = STATES_lmi(:, 1:n);
    X_hat_sim_lmi = STATES_lmi(:, n+1:2*n);
    U_sim_lmi = (-K_lmi_ctrl * X_hat_sim_lmi')'; 
    x_rel_sim_lmi = X_sim_lmi(:,1) - X_sim_lmi(:,3);

     figure('Name', 'LMI Observer-Controller Simulation');
     subplot(3, 2, 1); plot(T_lmi, X_sim_lmi(:,1), 'b-', T_lmi, X_hat_sim_lmi(:,1), 'r--'); title('Ball Position x_b'); legend('Actual', 'Estimated'); grid on;
     subplot(3, 2, 2); plot(T_lmi, X_sim_lmi(:,2), 'b-', T_lmi, X_hat_sim_lmi(:,2), 'r--'); title('Ball Velocity v_b'); legend('Actual', 'Estimated'); grid on;
     subplot(3, 2, 3); plot(T_lmi, X_sim_lmi(:,3), 'b-', T_lmi, X_hat_sim_lmi(:,3), 'r--'); title('Table Position x_t'); legend('Actual', 'Estimated'); grid on;
     subplot(3, 2, 4); plot(T_lmi, X_sim_lmi(:,4), 'b-', T_lmi, X_hat_sim_lmi(:,4), 'r--'); title('Table Velocity v_t'); legend('Actual', 'Estimated'); grid on;
     subplot(3, 2, 5); plot(T_lmi, x_rel_sim_lmi, 'k-'); title('Relative Position x_{rel}'); hold on; plot(T_lmi, zeros(size(T_lmi)), 'g:'); hold off; grid on;
     subplot(3, 2, 6); plot(T_lmi, U_sim_lmi, 'm-'); title('Control Input F (LMI)'); grid on; 
     
     figure('Name', 'LMI Estimation Error'); 
     plot(T_lmi, X_sim_lmi - X_hat_sim_lmi); title('State Estimation Error (X - X_{hat}) (LMI)'); legend('e_{xb}', 'e_{vb}', 'e_{xt}', 'e_{vt}'); grid on;
else
    fprintf('\nLMI controller or LMI observer未能成功设计，无法进行LMI部分的仿真。\n');
    if ~exist('K_lmi_ctrl','var') || isempty(K_lmi_ctrl); K_lmi_ctrl = nan(m_in, n); end
    if ~exist('L_lmi_obs','var') || isempty(L_lmi_obs); L_lmi_obs = nan(n, p); end
    if ~exist('A_obs_sim','var'); A_obs_sim = nan(n, n); end
    if ~exist('B_obs_sim','var'); B_obs_sim = nan(n, m_in+p); end
    if ~exist('C_obs_sim','var'); C_obs_sim = nan(n, n); end
    if ~exist('D_obs_sim','var'); D_obs_sim = nan(n, m_in+p); end
end

if ~exist('X0','var'); X0 = zeros(n,1); end
if ~exist('X0_hat','var'); X0_hat = zeros(n,1); end


% --- H_inf 控制器设计 ---
fprintf('\n--- H_inf 控制器设计 ---\n');
K_hinf = []; % Initialize H_inf controller
GAM_hinf = inf; % Initialize achieved gamma

if rank_Co == n && rank_Ob == n
    fprintf('系统可控且可观测，尝试设计H_inf控制器。\n');
    
    % H_inf 控制器参数 (与H2参数可以相同，或者根据H_inf目标调整)
    w_xrel = 1.0;      % Weight for relative position x_b - x_t
    w_xt = 5.0;        % Weight for table position x_t
    rho_hinf = 0.01;   % Control effort penalty (w_u^2 = rho_hinf)
    w_u = sqrt(rho_hinf); % Note: For H_inf, sometimes weights are set directly, not sqrt

    % 定义广义对象 P(s) 的状态空间矩阵 (与H2相同)
    Bw = B; 
    Bu = B; 

    Cz_hinf = [w_xrel * C(1,:);    % For w_xrel*(xb-xt)
               w_xt * [0 0 1 0];   % For w_xt*xt
               zeros(m_in, n)];   % Placeholder for w_u*u (comes from Dzu)
    
    Dzw_hinf = [zeros(1, size(Bw,2));     
                zeros(1, size(Bw,2));     
                zeros(m_in, size(Bw,2))]; 
    
    Dzu_hinf = [zeros(1, m_in);           
                zeros(1, m_in);           
                w_u * eye(m_in)];        

    Cy_hinf = C; 
    Dyw_hinf = zeros(p, size(Bw,2)); 
    Dyu_hinf = D; 

    B_generalized = [Bw, Bu];
    C_generalized = [Cz_hinf; Cy_hinf];
    D_generalized = [Dzw_hinf, Dzu_hinf; Dyw_hinf, Dyu_hinf];
    
    P_hinf = ss(A, B_generalized, C_generalized, D_generalized);
    
    nmeas = p; 
    ncont = m_in; 
    
    % H_inf specific: Gamma range for iteration (optional but often good practice)
    % You might need to adjust this range based on your problem.
    % If hinfsyn fails, try a wider range or a different starting guess.
    gamRange = [0.01 1000]; % Example range
    opts = hinfsynOptions('Display','on'); % To see gamma iteration progress

    try
        % For optimal H_inf, you might call hinfsyn multiple times (bisection)
        % or use hinfsyn with an objective to minimize gamma.
        % A simpler first attempt:
        fprintf('尝试使用 hinfsyn 自动寻找 gamma...\n');
        [K_hinf, CL_hinf, GAM_hinf, INFO_hinf] = hinfsyn(P_hinf, nmeas, ncont, opts);
        % If the above fails or GAM_hinf is too large, you might try with a specific gamRange:
        % fprintf('尝试使用 hinfsyn 和 gamRange = [%f, %f]...\n', gamRange(1), gamRange(2));
        % [K_hinf, CL_hinf, GAM_hinf, INFO_hinf] = hinfsyn(P_hinf, nmeas, ncont, gamRange, opts);

        if ~isempty(K_hinf) && isfinite(GAM_hinf) && GAM_hinf < gamRange(2) % Check if a valid controller was found
            fprintf('H_inf 控制器设计成功。\n');
            fprintf('获得的 H_inf 范数 GAM_hinf = %f\n', GAM_hinf);
            disp('H_inf 控制器 K_hinf:');
            disp(K_hinf);
            
            fprintf('H_inf 闭环系统 (w to z) 特征值:\n');
            eig_cl_hinf = pole(CL_hinf);
            disp(eig_cl_hinf);
            if all(real(eig_cl_hinf) < -1e-9) % Stricter check for stability
                fprintf('H_inf 控制器使闭环系统稳定。\n');
            else
                fprintf('警告: H_inf 控制器未能使闭环系统稳定或极点非常靠近虚轴。\n');
                % K_hinf = []; % Optionally invalidate if poles are too close to jw-axis
            end
        else
            fprintf('H_inf 控制器设计失败或未找到合适的 gamma。\n');
            if isfield(INFO_hinf, 'gamma')
                fprintf('上次尝试的 Gamma: %f\n', INFO_hinf.gamma);
            end
            K_hinf = [];
        end

    catch ME
        fprintf('H_inf 控制器设计失败: %s\n', ME.message);
        K_hinf = [];
    end
else
    fprintf('系统不可控或不可观测，无法设计H_inf控制器。\n');
    K_hinf = [];
end


% --- 仿真 (H_inf Controller) ---
if ~isempty(K_hinf)
    fprintf('\n--- 仿真 (H_inf Controller) ---\n');
    
    sys_plant_for_hinf_sim = ss(A, B, C, D); 
    sys_cl_hinf_sim = feedback(sys_plant_for_hinf_sim, K_hinf); % Negative feedback assumed
    
    t_sim_hinf = 0:0.01:15; % Renamed simulation time
    % X0 is already defined
    if ~isa(K_hinf, 'double') 
        X0_controller_hinf = zeros(size(K_hinf.A,1),1);
    else 
        X0_controller_hinf = []; 
    end
    X0_hinf_augmented = [X0; X0_controller_hinf];

    [~, T_hinf_sim, X_aug_hinf_sim] = initial(sys_cl_hinf_sim, X0_hinf_augmented, t_sim_hinf);
    
    X_plant_sim_hinf = X_aug_hinf_sim(:, 1:n);
    if ~isempty(X0_controller_hinf)
        X_ctrl_sim_hinf  = X_aug_hinf_sim(:, n+1:end);
    else
        X_ctrl_sim_hinf = []; 
    end
    
    U_sim_hinf = zeros(length(T_hinf_sim), m_in);
    if ~isa(K_hinf, 'double') % Dynamic controller K_hinf = ss(Ak,Bk,Ck,Dk)
        inv_term = eye(m_in); 
        if any(any(K_hinf.D)) && any(any(D))
            inv_term = inv(eye(m_in) - K_hinf.D * D);
        end

        for k_loop = 1:length(T_hinf_sim)
            xp_k = X_plant_sim_hinf(k_loop,:)';
            if ~isempty(X_ctrl_sim_hinf)
                xc_k = X_ctrl_sim_hinf(k_loop,:)';
            else
                xc_k = []; 
            end
            
            if ~any(any(D)) % Plant D is zero
                term_Dk_C_xp = K_hinf.D * C * xp_k;
            else
                % This case is more complex if D is not zero.
                % For simplicity, assuming D is zero as in your original setup.
                term_Dk_C_xp = K_hinf.D * C * xp_k;
            end
            
            if ~isempty(X_ctrl_sim_hinf)
                 U_sim_hinf(k_loop,:) = (inv_term * (K_hinf.C * xc_k + term_Dk_C_xp))';
            end
        end
    end
    
    x_rel_sim_hinf = X_plant_sim_hinf(:,1) - X_plant_sim_hinf(:,3);

    figure('Name', 'H_inf Controller Simulation');
    subplot(3,2,1); plot(T_hinf_sim, X_plant_sim_hinf(:,1), 'b-'); title('Ball Position x_b (Hinf)'); grid on;
    subplot(3,2,2); plot(T_hinf_sim, X_plant_sim_hinf(:,2), 'b-'); title('Ball Velocity v_b (Hinf)'); grid on;
    subplot(3,2,3); plot(T_hinf_sim, X_plant_sim_hinf(:,3), 'b-'); title('Table Position x_t (Hinf)'); grid on;
    subplot(3,2,4); plot(T_hinf_sim, X_plant_sim_hinf(:,4), 'b-'); title('Table Velocity v_t (Hinf)'); grid on;
    subplot(3,2,5); plot(T_hinf_sim, x_rel_sim_hinf, 'k-'); title('Relative Position x_{rel} (Hinf)'); hold on; plot(T_hinf_sim, zeros(size(T_hinf_sim)), 'g:'); hold off; grid on;
    subplot(3,2,6); plot(T_hinf_sim, U_sim_hinf, 'm-'); title('Control Input F (Hinf)'); grid on;

    if ~isempty(X0_controller_hinf) && ~isempty(X_ctrl_sim_hinf)
        figure('Name', 'H_inf Controller States');
        num_ctrl_states = size(X_ctrl_sim_hinf, 2);
        for i = 1:num_ctrl_states
            subplot(ceil(num_ctrl_states/2), 2, i);
            plot(T_hinf_sim, X_ctrl_sim_hinf(:,i));
            title(sprintf('H_inf Controller State x_{c%d}', i));
            grid on;
        end
    end
else
    fprintf('\nH_inf controller未能成功设计，无法进行H_inf仿真。\n');
end

% Final check variables for Simulink
if ~exist('K_lmi_ctrl','var'); K_lmi_ctrl = nan(m_in,n); end
if ~exist('L_lmi_obs','var'); L_lmi_obs = nan(n,p); end
% K_hinf is the H-infinity controller state-space object

